﻿using System.Collections;

/*
 * Created 20091211@Lee - Base UI interface
 * Revision: 
 * 20091211@Lee - Initializing
 * 
 * !!!CAUTION: ANY REVISION MUST BE APPROVED BEFORE PROCEEDING!!!
 * 
 */

namespace Olympus.LRF.UI._Base
{
    public interface IBasePage
    {
        /// <summary>
        /// Process the request and return requested params.
        /// </summary>
        /// <returns></returns>
        void ProcessRequest(ref Hashtable p);

        /// <summary>
        /// Validating the request with a list of request params.
        /// </summary>
        /// <param name="p">LicenseeWinlossList of request params</param>
        /// <returns>Null is success, otherwise is error</returns>
        object ValidateRequest(Hashtable p);

        /// <summary>
        /// Process data working with provided params.
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        object InvokeData(Hashtable p);
    }
}