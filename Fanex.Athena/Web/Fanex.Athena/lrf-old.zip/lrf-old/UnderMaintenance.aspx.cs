﻿using System;
using System.Configuration;
using System.Web.Security;
using System.Web.UI;
using DNAide.Core;
using Fanex.Athena.Service.Implement.Configuration;
using Fanex.Athena.Service.Interface.Configuration;
public partial class UnderMaintenance : BasePage
{
    private IMaintenanceService _maintenanceService = new MaintenanceService();

    protected string UmTimeFrom = string.Empty;
    protected string UmTimeTo = string.Empty;

    protected override void OnLoad(EventArgs e)
    {
        var maintenanceInfo = _maintenanceService.MaintenanceInfo;
        var acceptIp = ConfigurationManager.AppSettings["AcceptIp"];
        var isDeploying = acceptIp != "*" && Request.UserHostAddress != acceptIp;

        if (!isDeploying && !maintenanceInfo.IsDownTime)
        {
            Response.Redirect(FormsAuthentication.LoginUrl);
            Response.End();
        }
        else
        {
            UmTimeFrom = maintenanceInfo.UmTimeFrom;
            UmTimeTo = maintenanceInfo.UmTimeTo;

            if (string.IsNullOrEmpty(UmTimeFrom) || string.IsNullOrEmpty(UmTimeTo))
            {
                UmTimeFrom = CastAide.AsString(Request.QueryString["from"], string.Empty);
                UmTimeTo = CastAide.AsString(Request.QueryString["to"], string.Empty);
            }
        }

        base.OnLoad(e);
    }
}