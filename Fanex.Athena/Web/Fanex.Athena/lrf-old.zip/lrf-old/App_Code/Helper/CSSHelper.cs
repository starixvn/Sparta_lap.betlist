﻿using System.Web;

using Fanex.Athena.Extension.Utility;

/// <summary>
/// Summary description for CSSHelper
/// </summary>
public static class CSSHelper
{
    #region Constant

    const string DefaultTheme = "12Bet";
    const string CssLinkFormat = "<link href=\"{0}Content/Themes/{1}/Site.css?{2}\" rel='stylesheet' type='text/css' />";
    const string GlobalJsFormat = @"<script src='{0}_GlobalResources/Js/lib/jquery.min.js?{1}' type='text/javascript'></script>"
                                + @"<script src='{0}_GlobalResources/Js/lib/jquery.cookie.js?{1}' type='text/javascript'></script>"
                                + @"<script src='{0}_GlobalResources/Js/Core.js?{1}' type='text/javascript'></script>";

    const string GlobalCssFormat = "<link href=\"{0}Content/Global/Global.css?{1}\" rel='stylesheet' type='text/css' />";

    #endregion

    #region Static

    private static string GlobalJsLink;
    private static string GlobalCssLink;
   
    #endregion

    #region Constructor

    static CSSHelper()
    {
        var homePath = VirtualPathUtility.ToAbsolute("~/");
        GlobalJsLink = string.Format(GlobalJsFormat, homePath, AppSettings.JsVersion);
        GlobalCssLink = string.Format(GlobalCssFormat, homePath, AppSettings.JsVersion);
    }

    #endregion


    public static string ThemeCssLink
    {
        get
        {

            var homePath = VirtualPathUtility.ToAbsolute("~/");
            var themeCssLink = string.Format(CssLinkFormat, homePath, DefaultTheme, AppSettings.JsVersion);
            var globalResourcesLink = GlobalCssLink + themeCssLink + GlobalJsLink;

            return globalResourcesLink;
        }
    }

}
