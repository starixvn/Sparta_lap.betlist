﻿<%@ WebHandler Language="C#" Class="Olympus.LRF.UI._MemberInfo.ChangePassword.ChangePassword_Handler" %>

using System.Collections;
using Olympus.LRF.UI._Base;
using Olympus.LRF.UI._Definitions;
using Fanex.Athena.Service.Implement.Users;
using Fanex.Athena.Models.DTO.Users;
using Fanex.Athena.Models.DTO.Common;
/*
* Created 20100226@Terry, Lee - Handler for change password
* Revision ?@? - ... 
* 
*/


namespace Olympus.LRF.UI._MemberInfo.ChangePassword
{
    using Fanex.Athena.Models.DTO.Users;

    public class ChangePassword_Handler: TplHandler
    {
        public override void RenderResult(ref JSONData data)
        {
            var r = View as _Base.Result;
          
                data.AsResult(r);
            
        }

        string _oldPwd, _newPwd;
        public override void ProcessRequest(ref Hashtable p)
        {
            _newPwd = Request["txtNewPwd"];
            _oldPwd = Request["txtOldPwd"];
        }

        public override object ValidateRequest(Hashtable p)
        {
            if (!Validation.CheckValidPassword(_newPwd) || string.IsNullOrEmpty(_oldPwd))
            {
                return new _Base.Result(ErrorType.Unknown, Fanex.Athena.Models.ViewModel.ViewResources.PasswordNoteMsg);
            }

            return null;
        }

        public override object InvokeData(Hashtable p)
        {

            var userService = new UserService();
            if (LicenseeHelper.IsInternalLogin)
            {
                return new _Base.Result(ErrorType.AccessDenied, Fanex.Athena.Models.ViewModel.ViewResources.AccessDeniedMsg);
            }
            else
            {
                  var  _sessionService = new SessionService();
                  IResultInfo resultInfo = userService.ChangePassword(_sessionService.UserSession.UserName
                   , _oldPwd, _newPwd, Request.UserHostAddress);
                return new _Base.Result(resultInfo.Code, resultInfo.Message);
            }

            
        }
    }
}