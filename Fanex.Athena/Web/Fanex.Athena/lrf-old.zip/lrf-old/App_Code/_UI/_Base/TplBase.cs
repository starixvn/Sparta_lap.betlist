﻿using System.Collections;
using System.Collections.Generic;
using System.Web.UI;
using Fanex.Athena.Service.Implement.Common;
using Fanex.Athena.Service.Implement.Users;
using Fanex.Athena.Service.Interface.Common;
using Fanex.Athena.Service.Interface.Users;
using Olympus.LRF.UI._Base;

/*
 * Created 20091211@Lee - Base aspx page
 * Revision: 
 * 20091211@Lee - Initializing
 * 
 * !!!CAUTION: ANY REVISION MUST BE APPROVED BEFORE PROCEEDING!!!
 * 
 */

namespace IBC.Agent.UI._Base
{
    /// <summary>
    /// Base IBC page.
    /// </summary>
    public abstract class TplBase : Page, IBasePage
    {
        // Handle external resources of controls
        protected List<string> RegisteredControls = new List<string>(10);
        public ISessionService _sessionService = new SessionService();
        public ILanguageService _langService = new LanguageService();

        protected override void InitializeCulture()
        {
            base.InitializeCulture();
            var currentLang = _langService.GetCurrentLanguage();
            _langService.SetPageCulture(currentLang);
        }

        /// <summary>
        /// Data was loaded in InvokeData.
        /// </summary>
        protected object View;

        /// <summary>
        /// Parameters was parsed in the http request.
        /// </summary>
        protected Hashtable Parameters;

        #region IBasePage Members

        /// <summary>
        /// Process HttpRequest and return a list of using params.
        /// </summary>
        /// <param name="p">List of params are using in this page</param>
        public abstract void ProcessRequest(ref Hashtable p);

        /// <summary>
        /// Validating the request with a list of request params.
        /// </summary>
        /// <param name="p">List of request params</param>
        /// <returns>Null is success otherwise is error message</returns>
        public abstract object ValidateRequest(Hashtable p);

        /// <summary>
        /// Loading data in _BL with provided params. This function was called  in http get only. 
        /// Inherit from TplPage2 will be supported ProcessRequest method.
        /// </summary>
        /// <param name="p">List of request params</param>
        /// <returns>Return data in array of objects</returns>
        public abstract object InvokeData(Hashtable p);

        #endregion

        /// <summary>
        /// Return false that mean the control aldready registered.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public bool RegisterControl(string name)
        {
            if (RegisteredControls.Contains(name)) return false;
            RegisteredControls.Add(name);
            return true;
        }
    }
}