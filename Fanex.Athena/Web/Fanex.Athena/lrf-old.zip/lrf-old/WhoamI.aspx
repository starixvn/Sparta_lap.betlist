﻿<%@ Page Language="C#" EnableSessionState="False" %>

<%@ Import Namespace="System.Web" %>
<%@ Import Namespace="System.Web.Configuration" %>
<%@ Import Namespace="Sunplus.UMControllerLibrary" %>
<html xmlns="http://www.w3.org/1999/xhml">
<head id="Head1" runat="server">
    <title>Who am I</title>
    <script src="_GlobalResources/Js/lib/jquery.min.js" type="text/javascript"></script>
    <script src="_GlobalResources/Js/Core.js" type="text/javascript"></script>
    <script type="text/C#" runat="server">
        protected string _s = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            _s += "WebName: " + Request.ServerVariables["Server_Name"] + "<br />";
            _s += "Server IP : " + Request.ServerVariables["LOCAL_ADDR"].ToString() + "<br>";
            _s += "Client IP : " + Request.UserHostAddress.ToString() + "<br>";
            _s += "Now : " + DateTime.Now.ToString() + "<br/>";
        }
    </script>
</head>
<body style="font-size: 16px; background-color: #ffffff;">
    <%Response.Write(_s); %>
</body>
</html>
