﻿using System;
using System.Collections;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using Olympus.LRF.UI._Base;
using Olympus.LRF.UI._Components.DropDownList;
using Fanex.Athena.Service.Interface.Users;
using Fanex.Athena.Service.Implement.Users;
using Fanex.Athena.Extension.Utility;
using System.Text;
using Fanex.Athena.Service.Interface.Common;
using Fanex.Athena.Service.Implement.Common;
using Fanex.Athena.Models.ViewModel;

/*
 * Created 20100126@Lee - Render header page
 * Revision:
 * Don@20100617 -  Refactor user message function: remove codes of showing message when the first request is reached.
 * 
 */

namespace Olympus.LRF.UI._Header
{
    public partial class Header_Page : TplPage
    {
        private ILicenseeService _licenseeService = new LicenseeService();
        private ILanguageService langService = new LanguageService();
        protected override void InitializeCulture()
        {
            base.InitializeCulture();
            langService.SetPageCulture(langService.GetCurrentLanguage());
        }
        public override void ProcessRequest(ref Hashtable p)
        {
            int liceseeid = _sessionService.LicenseeSession.LicenseeId;
        }

        public override object ValidateRequest(Hashtable p)
        {
            return null;
        }

        public override object InvokeData(Hashtable p)
        {
            return null;
        }

        public override void RenderContent(HtmlTextWriter writer)
        {
            var session = _sessionService.UserSession;

            #region Registers javascript

            RegisterJavascriptObject("Language", session.Language);
            RegisterJavascriptObject("OnUserID", session.OnUserId);

            #endregion

            var tpl = new Header_Template();

            var licenseeList = _licenseeService.GetByUser(_sessionService.UserSession.UserId);
            // Do not show Licensee dropdownlist on header
            // if user is a licensee
            if (licenseeList.Count > 1)
            {
                string ddlLicensee = new LicenseeDropdownList("ChangeLicensee();").ToString();
                tpl.LicenseeList.LicenseeDropdownList = ViewResources.Licensee+ ": " + ddlLicensee;
            }
            else
            {
                tpl.LicenseeList.Hide();
            }

            //@Alex20110825
            //Remove ChangePass Link if user  logined from internal Site
            if (LicenseeHelper.IsInternalLogin)
            {
                tpl.ChangePassLink.Hide();
            }
            tpl.mainAccName = HttpUtility.HtmlEncode(session.UserName);

            //Do not include recheckin block in local test enviroment
            if (ConfigurationManager.AppSettings["LocalTest"] == "1"
                || ConfigurationManager.AppSettings["LocalTest"] == "true")
            {
                tpl.RecheckInJsBlock.Clear();
            }

            //clock
            tpl.Now = DateTime.Now.ToString();
            tpl.Gmt = DateTime.Now.ToString("%z");
            tpl.IsInternal = session.IsInternal ? "1" : "0";
            tpl.LogoutButton.Visible = !session.IsInternal;

            //render languageList
            tpl.LanguageList.Flag = session.Language;

            var languageList = Util.GetSupportedLanguage();
            var option = new StringBuilder();
            var optionTpl = "<option value=\"{0}\">{1}</option>";
            var optionTplSelected = "<option selected=\"selected\" value=\"{0}\">{1}</option>";
            foreach (var item in languageList)
            {
                if (item.Key.Equals(session.Language))
                {
                    option.Append(string.Format(optionTplSelected, item.Key, item.Value));
                }
                else
                {
                    option.Append(string.Format(optionTpl, item.Key, item.Value));
                }
            }
            tpl.LanguageList.Options = option.ToString();
            writer.Write(tpl);
        }
    }
}
