﻿/*
* Created 20100226@Lee - Error message javascript functions
* Revision ?@? - ... 
* 
*/



// Prototype
IbcMsg = function() {
    this.spmsgerr = 'spmsgerr';
    this.diverrmsg = 'diverrmsg';
}

IbcMsg.prototype.Show = function(msg, success) {

    if (success) {
        $('#spmsgerr').addClass('msgscc');
        document.getElementById('1_1').className = "succ_1_1";
        document.getElementById('1_2').className = "succ_1_2";
        document.getElementById('1_3').className = "succ_1_3";
        document.getElementById('2_1').className = "succ_2_1";
        document.getElementById('2_2').className = "succ_2_2";
        document.getElementById('3_1').className = "succ_3_1";
        document.getElementById('3_2').className = "succ_3_2";
        document.getElementById('3_3').className = "succ_3_3";
    }
    else {
        document.getElementById('spmsgerr').className = 'msgerr';
        document.getElementById('1_1').className = "emsg_1_1";
        document.getElementById('1_2').className = "emsg_1_2";
        document.getElementById('1_3').className = "emsg_1_3";
        document.getElementById('2_1').className = "emsg_2_1";
        document.getElementById('2_2').className = "emsg_2_2";
        document.getElementById('3_1').className = "emsg_3_1";
        document.getElementById('3_2').className = "emsg_3_2";
        document.getElementById('3_3').className = "emsg_3_3";    
    }

    $('#'+this.spmsgerr).html(msg);
    document.getElementById(this.diverrmsg).style.display = IE ? 'block' : 'table';
}

IbcMsg.prototype.Hide = function() {
    $('#'+this.diverrmsg).hide();
}

ibcMsg = new IbcMsg();