﻿// ----------------------------------------------------------------------
// <copyright file="DropDownList.cs" company="Sunplus Vietnam IT">
//     Copyright (c) LRF. All rights reserved
// </copyright>
// ------------------------------------------------------------------------
namespace Olympus.LRF.UI._Components.DropDownList
{
    using System.Collections.Generic;
    using System.Web;
    using TplCore.Element;

    /// <summary>
    /// Drop down list control
    /// Similar with asp drop down list
    /// </summary>
    public class DropDownList : IComponent
    {
        #region Field

        /// <summary>
        /// Flag to indicate the control is rendered or not
        /// </summary>
        private bool isRendered = false;

        /// <summary>
        /// The Html temlate
        /// </summary>
        private DropDownList_Template template = new DropDownList_Template();

        /// <summary>
        /// The selected value
        /// Can be set
        /// Can be get from the reqquest
        /// </summary>
        private string selectedValue;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the DropDownList class
        /// </summary>
        public DropDownList()
        {
            this.OnChangeFunction = string.Empty;
        }

        /// <summary>
        /// Initializes a new instance of the DropDownList class
        /// </summary>
        /// <param name="id">Client Id and Name of control</param>
        public DropDownList(string id)
        {
            this.ID = id;
            this.OnChangeFunction = string.Empty;
        }

        /// <summary>
        /// Initializes a new instance of the DropDownList class
        /// </summary>
        /// <param name="id">Client Id and Name of control</param>
        /// <param name="onChangeFunction">On change javascript function</param>
        public DropDownList(string id, string onChangeFunction)
        {
            this.ID = id;
            this.OnChangeFunction = onChangeFunction;
        }
        #endregion

        #region Property

        /// <summary>
        /// Gets or sets data source
        /// </summary>
        public Dictionary<string, string> DataSource { get; set; }

        /// <summary>
        /// Gets or sets client Id of the drop down list
        /// </summary>
        public string ID { get; set; }

        /// <summary>
        /// Gets or sets on client change function
        /// </summary>
        public string OnChangeFunction { get; set; }

        /// <summary>
        /// Gets or sets the selected value
        /// </summary>
        public virtual string SelectedValue
        {
            get
            {
                if (this.selectedValue != null)
                {
                    return this.selectedValue;
                }

                HttpContext context = HttpContext.Current;
                string postedValue = context.Request.Form[this.ID];
                string queryValue = context.Request.QueryString[this.ID];

                string result = postedValue != null
                                    ? postedValue
                                    : queryValue;
                                
                if (this.IsValidValue(result))
                {
                    return result;
                }

                return string.Empty;
            }

            set
            {
                if (this.IsValidValue(value))
                {
                    this.selectedValue = value;
                }
            }
        }

        /// <summary>
        /// Gets the selected text
        /// </summary>
        public virtual string SelectedText
        {
            get
            {
                if (this.SelectedValue != null)
                {
                    return string.Empty;
                }

                if (this.DataSource == null || this.DataSource.Count == 0)
                {
                    return string.Empty;
                }

                // Get by the key selectedValue
                return this.DataSource.ContainsKey(this.SelectedValue)
                    ? this.DataSource[this.SelectedValue]
                    : string.Empty;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the control is rendered or not
        /// </summary>
        protected virtual bool IsRendered
        {
            get { return this.isRendered; }
            set { this.isRendered = value; }
        }

        /// <summary>
        /// Gets the template for drop down list
        /// </summary>
        protected virtual DropDownList_Template Template
        {
            get { return this.template; }
        }
        #endregion

        #region String Convertion

        /// <summary>
        /// Operator string cast
        /// </summary>
        /// <param name="value">Drop down list need to cast </param>
        /// <returns>Html string</returns>
        public static implicit operator string(DropDownList value)
        {
            return value.ToString();
        }

        /// <summary>
        /// ToString method
        /// </summary>
        /// <returns>Html string</returns>
        public override string ToString()
        {
            if (!this.isRendered)
            {
                this.Render();
            }

            return this.template.ToString();
        }

        #endregion

        #region IComponent Members

        /// <summary>
        /// Hide linked resources such as css and js
        /// </summary>
        public void HideLinkedResources()
        {
        }

        #endregion

        #region Render Utility

        /// <summary>
        /// Render the html for control
        /// </summary>
        protected virtual void Render()
        {
            this.isRendered = true;

            this.template.ID = this.ID;
            this.template.OnChangeFunc = this.OnChangeFunction;

            this.template.Option.Clear();
            string selectedId = this.SelectedValue;
            if (null != this.DataSource && this.DataSource.Count > 0)
            {
                var block = new DropDownList_Option_Block();
                foreach (string key in this.DataSource.Keys)
                {
                    block.ValueField = key;
                    block.TextField = this.DataSource[key];
                    block.Selected = selectedId == block.ValueField ? "selected='selected'" : string.Empty;
                    this.template.Option.Append(block);
                }
            }
        }

        #endregion

        #region Utility

        /// <summary>
        /// Indicating whether the data source contains the value or not
        /// </summary>
        /// <param name="value">The value need to validate</param>
        /// <returns>The value is valid or not</returns>
        protected virtual bool IsValidValue(string value)
        {
            if (value == null
                || this.DataSource == null
                || this.DataSource.Count == 0)
            {
                return false;
            }

            return this.DataSource.ContainsKey(value) ? true : false;
        }
        #endregion
    }
}