﻿using Olympus.LRF.UI._Components.ErrorPage;

/*
 * Created 20091211@Lee - Common error message page
 * Revision:
 * 
 * 
 */


namespace Olympus.LRF.UI._Components
{
    public class ErrorPage_Page
    {
        private string _error;
        ErrorPage_Template tpl = new ErrorPage_Template();

        public string Error
        {
            get { return _error; }
            set { _error = value; }
        }

        public ErrorPage_Page(string error)
        {
            _error = error;
        }

        public static implicit operator string(ErrorPage_Page value)
        {
            return value.ToString();
        }

        public override string ToString()
        {
            tpl.errorMsg = _error;
            return tpl.ToString();
        }
    }

}