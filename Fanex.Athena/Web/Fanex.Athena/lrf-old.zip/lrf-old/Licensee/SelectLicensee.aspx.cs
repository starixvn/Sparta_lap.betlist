﻿using System;
using System.Web.Security;
using Fanex.Athena.Service.Implement.Users;
using Fanex.Athena.Service.Interface.Users;


public partial class Licensee_SelectLicensee : BasePage
{
    #region Members

    private readonly ISessionService _sessionService = new SessionService();
    private readonly ILicenseeService _licenseeService = new LicenseeService();

    #endregion

    #region Events

    protected override void OnInit(EventArgs e)
    {
        var isSessionValid = _sessionService.UserSession != null
            && _sessionService.UserSession.UserId > 0;
        if (!isSessionValid)
        {
            LicenseeHelper.RedirectToSigninPage();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (string.IsNullOrEmpty(Request["LicenseeId"]))
            {
                LoadLicensee();
            }
            else
            {
                int licenseeId = LicenseeHelper.GetRequestLicenseeId();
                RedirectFromLoginPage(licenseeId);
            }
        }
    }

    #endregion

    #region Utilities

    private void LoadLicensee()
    {
        var licenseeList = _licenseeService.GetByUser(_sessionService.UserSession.UserId);
        //Admin, but not assinged to handle any licensees
        if (licenseeList.Count <= 0)
        {
            LicenseeHelper.RedirectToSigninPage();
        }

        //Admin user handle only one licensee
        if (licenseeList.Count == 1)
        {
            RedirectFromLoginPage(licenseeList[0].Id);
            return;
        }

        dlLicensee.DataSource = licenseeList;
        dlLicensee.DataBind();
    }

    protected string CurrentUsername()
    {
        if (_sessionService.UserSession != null)
        {
            return _sessionService.UserSession.UserName;
        }

        LicenseeHelper.RedirectToSigninPage();
        return string.Empty;
    }

    private void RedirectFromLoginPage(int licenseeId)
    {
        _sessionService.UpdateLiceseeSession(licenseeId);

        FormsAuthentication.RedirectFromLoginPage(_sessionService.UserSession.UserName, false);
    }

    #endregion
}