﻿/*
* Created 20100113@Lee - Sign-in javascript functions
* Revision ?@? - ... 
* 
*/
var LanguageMessages = {
    errUserName: "Please input username and password",
    errValidCode: "You must input validation code."
};

function DoLogin() {
    var errObj = LanguageMessages;
    if ($('#txtUserName').val() == "") {
        $("#errmsg").html(errObj.errUserName);
        $('#txtUserName').focus();
        return false;
    }
    if ($('#txtPassWord').val() == "") {
        $("#errmsg").html(errObj.errUserName)
        $('#txtPassWord').focus();
        return false;
    }
    if ($('#txtCaptcha').val() == "") {
        $("#errmsg").html(errObj.errValidCode);
        $('#txtCaptcha').focus();
        return false;
    }

    $('#btnLogin').attr('disabled', 'disabled');

    document.fLogin.submit();

    return true;
}

function GetValidateImage() {
    var objDate = new Date();
    $("#imgCode").attr("src", "Handlers/Captcha.ashx?code=" + objDate.getMilliseconds());

    setTimeout(GetValidateImage, 120000);
}

function InitLogin() {
    // Do not allow wrapping sign-in page
    if (window.parent != window) {
        window.parent.location = location.href;
    }

    setTimeout(GetValidateImage, 120000);

    if (typeof _page.errCode != 'undefined' && _page.errCode != 0) {
        $("#errmsg").html(_page.errMsg);
        if (_page.errCode == 101) {
            $('#txtCaptcha').focus();
        }
    }
}

$(window).load(function () {
    InitLogin();

});
