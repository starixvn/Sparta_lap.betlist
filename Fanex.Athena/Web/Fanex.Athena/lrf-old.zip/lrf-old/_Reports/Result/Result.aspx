﻿<%@ Page Language="C#" AutoEventWireup="true" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    <script runat="server">
        protected void Page_Load(object sender, EventArgs e)
        {
           HttpContext.Current.Response.RedirectToRoute(new
            {
                Controller = "Report",
                Action = "Result"
            });
        }

    </script>
    </div>
    </form>
</body>
</html>
