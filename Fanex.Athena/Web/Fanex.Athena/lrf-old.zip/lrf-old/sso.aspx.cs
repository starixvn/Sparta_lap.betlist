﻿using System;
using Fanex.Athena.Service.Implement.Configuration;
using Fanex.Athena.Service.Interface.Configuration;

public partial class sso : BasePage
{
    private IMaintenanceService _maintenanceService = new MaintenanceService();

    protected override void OnLoad(EventArgs e)
    {
        if (_maintenanceService.MaintenanceInfo.IsDownTime)
        {
            Server.Transfer("~/UnderMaintenance.aspx");
        }
        else
        {
            (new SSOHelper()).SSO();
        }
    }
}
