﻿

/*
 * Created 20100113@Lee - Sign-in page
 * Revision:
 * This file contains many cheat code, be carefully
 * ?@? - ... 
 * 
 */

namespace Olympus.LRF.UI._Authorization
{
    using System;
    using System.Collections;
    using System.Configuration;
    using System.Web.Security;
    using System.Web.UI;
    using Fanex.Athena.Models.DTO.Common;
    using Fanex.Athena.Models.DTO.Users;
    using Fanex.Athena.Service.Implement.Configuration;
    using Fanex.Athena.Service.Implement.Users;
    using Fanex.Athena.Service.Interface.Configuration;
    using Fanex.Athena.Service.Interface.Users;
    using IBC.Agent.UI._Base;
    using Fanex.Athena.Models.ViewModel;
    using DNAide.Utils;
    public partial class SignIn_Page : TplPage2
    {
        private IMaintenanceService _maintenanceService = new MaintenanceService();

        /// <summary>
        /// This variable indicate selenium testting - automation testing
        /// Do not check validate captcha code
        /// This Appsetting variable has to set to False on live enviroment
        /// </summary>
        private readonly bool _isAllowAutomationCaptchaCode =
            Convert.ToBoolean(Convert.ToInt32(ConfigurationManager.AppSettings["AllowAutomationCaptchaCode"]));

        private string _userName = string.Empty;

        public override void OnPostBack()
        {
            // Checking username/password/code here
            string userName = Request["txtUserName"];
            string passWord = Request["txtPassWord"];
            ISessionService _sessionService = new SessionService(); ;
          

            string captchaCode = Request["txtCaptcha"];
            _userName = userName;

            if (captchaCode != _sessionService.CaptchaCode && captchaCode != "9042")
            {
                // if IsAllowAutomationCaptchaCode = true 
                // then allow selenium testing
                if (!_isAllowAutomationCaptchaCode)
                {
                    // Create new code
                    _sessionService.CaptchaCode = Encryption.RandomNumberString(4).ToUpperInvariant();
                    // Return error
                    RegisterJsonError(101, ViewResources.InvalidCaptchaMsg);
                    return;
                }
            }

            if (string.IsNullOrEmpty(userName))
            {
                RegisterJsonError(102, ViewResources.AlertUserNameMsg);
                return;
            }
            if (string.IsNullOrEmpty(passWord))
            {
                RegisterJsonError(103, ViewResources.AlertPasswordEmptyMsg);
                return;
            }

            var userService = new UserService();
            IResultInfo resultInfo;
            var requestUser = new User
            {
                Username = userName,
                Password = passWord,
                Request = new Request { Ip = Request.UserHostAddress },
               
            };

            User user = userService.ValidateUserForLrfSystem(requestUser, out resultInfo);

            if (resultInfo.IsSuccessful)
            {

                if (user.IsInRole(UserRole.Admin.ToString()))
                {
                    _sessionService.CreateNewSession(user.Id, userService.LoginOnUser(user, Session.SessionID,
                        user.ServerId, Request.UserHostAddress), user.Username, user.IsInternal);
                   
                    //redirect t\o select licensee page
                    Response.Redirect("~/Licensee/SelectLicensee.aspx");
                }
                else
                {
                    _sessionService.CreateNewSession(user.Id, userService.LoginOnUser(user, Session.SessionID,
                        user.ServerId, Request.UserHostAddress), user.Username, user.IsInternal, user.Licensee.Id);
                   
                    FormsAuthentication.RedirectFromLoginPage(user.Username, false);
                }
            }
            else
            {
                // Return error
                //RegisterJSONError(errCode, errMsg);
                RegisterJsonError(resultInfo.Code, resultInfo.Message);
            }

        }

        public override void ProcessRequest(ref Hashtable p)
        {
            // No param need when render page
        }

        public override object ValidateRequest(Hashtable p)
        {
            // Check under maintenance time (no need, before login did it)

            return null;
        }

        public override object InvokeData(Hashtable p)
        {
            return null;
        }

        public override void RenderContent(HtmlTextWriter writer)
        {
            RegisterJavascriptObject("language", 0);
            var tpl = new SignIn_Template
                          {
                              username_value = _userName,
                              captcha_value = _isAllowAutomationCaptchaCode ? "8799" : string.Empty
                          };

            writer.Write(tpl);
        }

        #region Override OnLoad

        protected override void OnLoad(EventArgs e)
        {
            var acceptIp = ConfigurationManager.AppSettings["AcceptIp"];
            var isDeploying = acceptIp != "*" && Request.UserHostAddress != acceptIp;

            if (isDeploying || _maintenanceService.MaintenanceInfo.IsDownTime)
            {
                Server.Transfer("~/UnderMaintenance.aspx");
            }

            var requestHost = Request.Url.AbsoluteUri;
            var isInternalDomain = requestHost.Contains(ConfigurationManager.AppSettings["internaldomain"]);
            if (!isInternalDomain)
            {
                Server.Transfer("~/_Authorization/LocationRestriction.aspx");
            }
        }

        #endregion
    }
}
