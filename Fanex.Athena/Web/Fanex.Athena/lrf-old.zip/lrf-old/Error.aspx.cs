﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Error :System.Web.UI.Page
{
    protected override void OnLoad(EventArgs e)
    {
        string errorStr = string.Empty;
        string errCode = Request.QueryString["err"];
        if (string.IsNullOrEmpty(errCode)) errCode = string.Empty;
        switch (errCode)
        {
            case "400":
                errorStr = Fanex.Athena.Models.ViewModel.ViewResources.InvalidRequestMsg;
                break;
            case "403":
                errorStr = Fanex.Athena.Models.ViewModel.ViewResources.HttpError_403;
                break;
            case "404":
                errorStr = Fanex.Athena.Models.ViewModel.ViewResources.HttpError_404;
                break;
            default:
                errorStr = Fanex.Athena.Models.ViewModel.ViewResources.HttpError_Default;
                break;
        }
        if (string.IsNullOrEmpty(errorStr))
            errorStr = Fanex.Athena.Models.ViewModel.ViewResources.HttpError_Default;

        this.ErroStr.Text = errorStr;
    }
   
}
