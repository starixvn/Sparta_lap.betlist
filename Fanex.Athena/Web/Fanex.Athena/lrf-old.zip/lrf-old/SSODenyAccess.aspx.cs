﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Fanex.Athena.Models.ViewModel;

public partial class SSODenyAccess : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            var code = RequestHelper.GetIntRequest("Code", 0);
            var mess = RequestHelper.GetStringRequest("Mess", string.Empty);
            if (!string.IsNullOrEmpty(mess))
            {
                this.LiteralDenyLogin.Text = mess;
            }
            else
            {
                switch (code)
                {
                    case -1:
                        this.LiteralDenyLogin.Text = ViewResources.InValidParamMsg;
                        break;
                    case -2:
                        this.LiteralDenyLogin.Text = ViewResources.ExpiredTimeParamMsg;

                        break;
                    case -3:
                        this.LiteralDenyLogin.Text =  ViewResources.DisableSSOMsg;

                        break;
                    case -4:
                        this.LiteralDenyLogin.Text =  ViewResources.UnAccessLoginMsg;

                       
                        break;

                }
            }
        }
    }
}
