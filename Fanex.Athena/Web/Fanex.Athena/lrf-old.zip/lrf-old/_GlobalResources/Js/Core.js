﻿/*
* Created 20091224@Lee - Core javascript functions and classes
*
* !!!CAUTION: ANY REVISION MUST BE APPROVED BEFORE PROCEEDING!!!
* Revision ?@? - ... 
* 
*/
var QueryString = (function ($) {

    var parseQueryString = function (queryString) {
        var args = queryString.split('&');
        var argsList = {};

        for (var i = 0; i < args.length; i++) {

            var arg = unescape(args[i]);
            if (arg.length > 0) {
                if (arg.indexOf('=') == -1) {
                    argsList[$.trim(arg.toLowerCase())] = null;
                }
                else {
                    var keyValuePair = arg.split('=');
                    argsList[$.trim(keyValuePair[0].toLowerCase())] = $.trim(keyValuePair[1]);
                }
            }
        }

        return argsList;
    };

    var getQueryString = function (url) {

        var index = url.indexOf("?");
        return index < 0 ? "" : url.substring(index + 1, url.length);
    };

    var getRawUrl = function (url) {

        var index = url.indexOf("?");
        return index < 0 ? url : url.substring(0, index);
    };

    return {
        setParam: function (url, name, value) {
            var rawUrl = getRawUrl(url);
            var queryString = getQueryString(url);
            var args = parseQueryString(queryString);

            if (name == null || name == undefined) {
                return url;
            }

            // Update value
            var found = false;
            for (var key in args) {
                if (key != null && key != undefined && key.toLowerCase() == name.toLowerCase()) {
                    // Does not update data if value = undefined
                    if (value != undefined) {
                        args[key] = value;
                    }
                    found = true;
                }
            }

            if (!found) {
                args[name.toLowerCase()] = value;
            }

            var queryArray = [];

            // Rebuild query string, ignore null value
            for (var key in args) {
                if (args[key] != null && args[key] != undefined) {
                    queryArray.push(key.toLowerCase() + "=" + args[key]);
                }
            }

            return rawUrl + "?" + queryArray.join("&");

        },
        getParam: function (url, name) {
            var queryString = getQueryString(url);
            var args = parseQueryString(queryString);

            for (var key in args) {
                if (key != null && key.toLowerCase() == name.toLowerCase()) {
                    return args[key];
                }
            }

            return null;
        }
    }
})(jQuery);

function inc(filename) {
    var body = document.getElementsByTagName('body').item(0);
    script = document.createElement('script');
    script.src = filename;
    script.type = 'text/javascript';
    body.appendChild(script)
}

// String prototype
// Returns the string with all the beginning
// and ending whitespace removed
String.prototype.trim = function () {
    return this.replace(/^\s+/, '').replace(/\s+$/, '');
};

String.prototype.endsWith = function (str) {
    var lastIndex = this.lastIndexOf(str);
    return (lastIndex != -1) && (lastIndex + str.length == this.length);
};
String.prototype.contains = function (sub) {
    return this.indexOf(sub, 0) != -1;
}


// End of String prototype

function SetParameterValue(name, value, url) {

    return QueryString.setParam(url, name, value);
    //    var isNullValue = value == null || value == undefined;
    //    var joinChar = url.endsWith("?") || url.endsWith("&")
    //                                ? ""
    //                                : url.indexOf('?') == -1 ? "?" : "&";

    //    value = encodeURIComponent(value);
    //    value = value.replace(/\+/g, "%20");

    //    var newParameter = isNullValue ? "" : name + "=" + value;

    //    // Not contain?
    //    if (!url.contains("&" + name + "=")
    //                && !url.contains("?" + name + "=")) {
    //        return isNullValue ? url : url + joinChar + newParameter;
    //    }

    //    // Already contain ?
    //    var separator = url.contains("?" + name + "=") ? "?" : "&";

    //    var i1 = url.indexOf(separator + name + "=");

    //    var tmp = url.substr(i1);
    //    var i2 = tmp.indexOf("&", 1);

    //    var oldParameter = i2 >= 0 ? url.substr(i1, i2) : tmp;

    //    if (isNullValue) {
    //        url = url.replace(oldParameter, separator);
    //        url = url.replace("?&", "?");
    //        url = url.replace("&&", "&");
    //    }
    //    else {
    //        return url.replace(oldParameter, separator + newParameter);
    //    }

    //    return url;
}

function GetParameterValue(name, url) {

    return QueryString.getParam(url, name);

    //    if (null == url || null == name || 0 == name.length) return null;

    //    var urlToCompare = url.toLowerCase();
    //    name = name.toLowerCase();

    //    var separator = urlToCompare.contains("?" + name + "=") ? "?" : "&";

    //    var parameter = separator + name + "=";

    //    var i1 = urlToCompare.indexOf(parameter);
    //    if (i1 == -1) return null;

    //    var tmp = url.substr(i1);
    //    var i2 = tmp.indexOf("&", 1);

    //    var value = i2 >= 0 ? tmp.substr(parameter.length, i2 - parameter.length) : tmp.substr(parameter.length);

    //    value = decodeURIComponent(value.replace(/\+/g, " "));
    //    return value;
}

function GetUrlWithoutSegment(url) {
    var lastIndex = url.lastIndexOf("#");
    return lastIndex < 0 ? url : url.substring(0, lastIndex);
}

// Cookie
function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}


function setCookie(name, value, days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();
    }
    else var expires = "";
    document.cookie = name + "=" + value + expires + "; path=/";
}


// Prototype of IBC
function IBC() { };
// !!!IMPORTANT: isSingle = true if you want just one function for this event
IBC.prototype.addEvent = function (el, evname, func, isSingle) {
    if (el.attachEvent && isSingle != true) { // IE
        el.attachEvent("on" + evname, func);
    } else if (el.addEventListener && isSingle != true) { // Gecko / W3C
        el.addEventListener(evname, func, true);
    } else { // Opera (or old browsers)
        el["on" + evname] = func;
    }
}

IBC.prototype.removeEvent = function (el, evname, func) {
    if (el.detachEvent) { // IE
        el.detachEvent("on" + evname, func);
    } else if (el.removeEventListener) { // Gecko / W3C
        el.removeEventListener(evname, func, true);
    } else { // Opera (or old browsers)
        el["on" + evname] = null;
    }
}

IBC.prototype.stopEvent = function (ev) {
    if (IE) {
        window.event.cancelBubble = true;
        window.event.returnValue = false;
    } else {
        ev.preventDefault();
        ev.stopPropagation();
    }
    return false;
};

// Create a html element
IBC.prototype.createElement = function (type, parent) {
    var el = null;
    if (document.createElementNS) {
        // use the XHTML namespace; IE won't normally get here unless
        // _they_ "fix" the DOM2 implementation.
        el = document.createElementNS("http://www.w3.org/1999/xhtml", type);
    } else {
        el = document.createElement(type);
    }
    if (typeof parent != "undefined") {
        parent.appendChild(el);
    }
    return el;
}

// Which element is nearer origin Oxy
IBC.prototype.beforeElement = function (o1, o2) {
    if (typeof o2 == 'undefined') return o1;
    if (typeof o1 == 'undefined') return o2;

    // Tto get offset position
    o1.style.position = 'relative';
    o2.style.position = 'relative';

    // Compare distance from origin
    var d1 = o1.offsetTop * o1.offsetTop + o1.offsetLeft * o1.offsetLeft;
    var d2 = o2.offsetTop * o2.offsetTop + o2.offsetLeft * o2.offsetLeft;

    if (d1 > d2) return o2;
    else return o1;
}

// Find first form element in px position with tag name
IBC.prototype.firstFormElement = function (tag) {
    var items = document.getElementsByTagName(tag);
    if (items.length > 0) {
        var c = items.length > 5 ? 5 : items.length;
        for (var i = 0; i < c; i++) {
            if (
                !items[i].getAttribute('noFocus') &&    // property indicate do not focus on this item
                !items[i].disabled &&
                items[i].type != 'hidden' &&
                !items[i].readonly &&
                items[i].type != 'checkbox' &&
                items[i].type != 'radio'
                ) {
                return items[i];
            }
        }
    }
}

// Calculate view area
IBC.prototype.CalculateViewport = function () {
    this.viewport = function () { };

    if (!IE) {
        // in standards compliant mode (i.e. with a valid doctype as the first line in the document)
        if (typeof document.documentElement != 'undefined'
         && typeof document.documentElement.scrollWidth != 'undefined'
         && document.documentElement.scrollWidth != 0) {
            this.viewport.width = document.documentElement.scrollWidth;
            this.viewport.height = document.documentElement.scrollHeight;
        }

        this.viewport.width = Math.max(this.viewport.width, (Math.max(document.body.scrollWidth, document.body.clientWidth)));
        this.viewport.height = Math.max(this.viewport.height, (Math.max(document.body.scrollHeight, document.body.clientHeight)));
    }
    else {
        // in standards compliant mode (i.e. with a valid doctype as the first line in the document)
        if (typeof document.documentElement != 'undefined'
         && typeof document.documentElement.clientWidth != 'undefined'
         && document.documentElement.clientWidth != 0) {
            this.viewport.width = document.documentElement.clientWidth;
            this.viewport.height = document.documentElement.clientHeight;
        }

        this.viewport.width = Math.max(document.body.scrollWidth, this.viewport.width);
        this.viewport.height = Math.max(document.body.scrollHeight, this.viewport.height);
    }
}

// Create a mask div will cover whole page
IBC.prototype.CreateMaskDiv = function () {
    this.divMaskLoading = this.createElement("div");
    var div1 = this.createElement("div");
    div1.style.width = '100px'; div1.style.height = '100px';
    div1.style.position = 'relative';
    this.divMaskLoading.style.display = 'none';
    this.divMaskLoading.style.position = 'absolute';
    this.divMaskLoading.style.top = '0px';
    this.divMaskLoading.style.left = '0px';
    this.divMaskLoading.style.filter = 'alpha(opacity=50)';
    this.divMaskLoading.style.opacity = '0.5';
    this.divMaskLoading.style.backgroundColor = 'white';
    this.divMaskLoading.appendChild(div1);
    document.body.appendChild(this.divMaskLoading);
}

IBC.prototype.RemoveBookmarksInUrl = function (url) {
    if (typeof url != 'string') return null;
    var i = url.indexOf('#');
    if (i == -1) return url;
    return url.substr(0, i);
}

// Show a mask div cover whole page
IBC.prototype.ShowMaskDiv = function (withIcon) {
    if (!this.divMaskLoading) return;

    this.CalculateViewport();

    this.divMaskLoading.style.width = (this.viewport.width - 2) + 'px';
    this.divMaskLoading.style.height = (this.viewport.height - 2) + 'px';

    this.divMaskLoading.firstChild.style.left = Math.floor(this.viewport.width / 2) + 'px';
    this.divMaskLoading.firstChild.style.top = document.documentElement.scrollTop + 'px';

    this.divMaskLoading.firstChild.className = withIcon ? 'MaskLoadingDiv' : '';

    this.divMaskLoading.style.display = 'block';
}

// Hide showed mask div
IBC.prototype.HideMaskDiv = function () {
    if (!this.divMaskLoading) return;
    this.divMaskLoading.style.display = 'none';
}

// Reload page with provided url and delay time
IBC.prototype.DelayReloadPage = function (url, time) {
    this.ShowMaskDiv(true);
    var delay = time ? time : 2000;
    if (!url) {
        location.nextUrl = this.RemoveBookmarksInUrl(location.href);
        this.delayTimer = setTimeout("location = location.nextUrl", delay);
    }
    else {
        this.delayTimer = setTimeout("location = '" + url + "'", delay);
    }
}

// Catch enter event and do the action, using by onkeydown="ibc.DoEnter(...)"
IBC.prototype.DoEnter = function (evt, action) {
    if (null == ibc) return;
    if (IE) {
        if (window.event.keyCode == 13) eval(action);
    }
    else {
        if (evt.keyCode == 13) eval(action);
    }
}

IBC.prototype.Lock = function (withIcon) {
    this.ShowMaskDiv(withIcon);
    this.locked = true;
}

IBC.prototype.UnLock = function () {
    this.HideMaskDiv();
    this.locked = false;
}

// Refresh whole site to update session, cookies...
IBC.prototype.Refresh = function () {
    var wnd = window.parent;
    while (wnd != wnd.parent) // Jump out
    {
        wnd = wnd.parent;
    }

    wnd.location = wnd.location.href;
}

IBC.prototype.GetBaseUrl = function () {

    var url = window.location.href;
    var mark = '))/';
    var end = url.indexOf(mark);
    if (end == -1) {
        var slashNum = 3; // Public site
        if (url.indexOf('.com') == -1 && url.indexOf('.net') == -1 && url.indexOf('.org') == -1) slashNum = 4; // Local site
        end = 0;
        for (var i = 0; i < slashNum; i++) {

            end = url.indexOf('/', end + 1);
            if (end == -1) return null;
        }
        end++;
    }
    else {
        end += mark.length;
    }

    return url.substr(0, end);
}

IBC.prototype.GetQueryString = function (key, defaultValue) {
    if (defaultValue == null) defaultValue = "";
    key = key.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regex = new RegExp("[\\?&]" + key + "=([^&#]*)");
    var qs = regex.exec(window.location.href);
    if (qs == null)
        return defaultValue;
    else
        return qs[1];
}
/*End*/




// Detect browser
function isIE() { return /msie/i.test(navigator.userAgent) && !/opera/i.test(navigator.userAgent); }
IE = isIE();






/**************OPEN START-UP SECTION**************/
_page = {};  // root JSON object

var _startupCommands = new Array();
function RegisterStartUp(command) {
    _startupCommands.push(command);
}

// Delay init object to window.onload event to boots up performance
ibc = null;


function _startup() {
    if ($("div#header-title").length > 0) {
        parent.document.title = document.title;
    }

    ibc = new IBC();

    // Focus at startup
    if (typeof _focusElementId == 'undefined') {
        var input = ibc.firstFormElement("input");
        var select = ibc.firstFormElement("select");
        var item = ibc.beforeElement(input, select);
        try { if (item) item.focus(); }
        catch (e) { }
    }
    else if (_focusElement != -1) {
        var _focusElement = $("#" + _focusElementId);
        if (_focusElement != null && typeof _focusElement == 'object') _focusElement.focus();
    }

    // Create div
    ibc.CreateMaskDiv();

    // Calculate width and height of view port
    ibc.CalculateViewport();

    // Execute startup commands
    var commands = _startupCommands.join(';');
    eval(commands);

    window.loaded = true;
}


/************CLOSE START-UP SECTION*****************/

/*
* Created 20091224@Lee - Common business javascript functions
* Revision ?@? - ... 
* 
*/

// Frameset
// top.menu, top.main, top.frHeader, top.frFooter

// Error code
var UNKNOWN = -1;
var ACCESS_DENIED = 1;
var ACCOUNT_CLOSED = 2;
var KICKED_OUT = 3;
var UNDER_MAINTENANCE = 4;

// Reload frames to update language or configuration
IBC.prototype.Invalidate = function () {
    top.menu.location = ibc.RemoveBookmarksInUrl(top.menu.location.href);
    top.frHeader.location = ibc.RemoveBookmarksInUrl(top.frHeader.location.href);
    top.main.location = ibc.RemoveBookmarksInUrl(top.main.location.href);
    top.frFooter.location = ibc.RemoveBookmarksInUrl(top.frFooter.location.href);
}


// SignOut
IBC.prototype.SignOut = function () {

    var index = window;
    while (index != index.parent) // Jump out
    {
        index = index.parent;
    }
    index.location = ibc.GetBaseUrl() + '_Authorization/Handlers/SignOut.ashx';
}


// Password must be at least 6 in length and at least 2 characters and 2 digits
function IsPassWord(str) {
    numbers = "0123456789";
    var i = 0;
    var nCount = 0;
    while (i < str.length) {
        (numbers.indexOf(str.substring(i, i + 1)) >= 0) ? nCount++ : false;
        i++;
    }
    return ((nCount > (str.length - 2)) || nCount < 2 || str.length < 6) ? false : true;
}

// Add popup height when show error
var _preHeight = 0;
function AddPopupHeight(h) {
    ibcWnd = parent.ibcWnd;

    if (typeof ibcWnd == 'undefined') return;

    if (_preHeight == 0) {
        _preHeight = ibcWnd.height;
    }

    ibcWnd.setRect(null, null, ibcWnd.width, _preHeight + h);
}


function ShowLoading(loadingId) {
    if (!loadingId) loadingId = "loading";
    var loading = $("#" + loadingId);
    if (loading.length > 0) {
        loading.attr("class", "loading");
    }
}
/*End*/


function UpdateCurrencyParameter(url) {

    var licenseeType = $("#LicenseeType");
    var currencyId = $("#CurrencyId");
    var isConvert = $("#IsConvert");
    var licenseeTypeValue = licenseeType.length > 0 ? licenseeType.val() : null;
    var currencyIdValue = currencyId.length > 0 ? currencyId.val() : null;
    var isConvertValue = isConvert.length > 0 ? isConvert.is(":checked") : null;


    url = SetParameterValue("LicenseeType", licenseeTypeValue, url);
    url = SetParameterValue("CurrencyId", currencyIdValue, url);
    url = SetParameterValue("IsConvert", isConvertValue, url);

    return url;
}


function SetOriginalCurrencyParameter(url) {

    var licenseeType = $("#OriginalLicenseeType");
    var currencyType = $("#OriginalCurrencyType");
    var currencyId = $("#OriginalCurrencyId");
    var isConvert = $("#OriginalIsConvert");

    url = SetParameterValue("LicenseeType", licenseeType.length > 0 ? licenseeType.val() : null, url);
    url = SetParameterValue("CurrencyType", currencyType.length > 0 ? currencyType.val() : null, url);
    url = SetParameterValue("CurrencyId", currencyId.length > 0 ? currencyId.val() : 0, url);
    url = SetParameterValue("IsConvert", isConvert.length > 0 ? isConvert.val() : null, url);

    return url;
}

function SetOriginalSportTypeParams(url) {

    $("input.original_sportfilter").each(function (index, obj) {
        var key = $(obj).attr("id").substring(9);
        url = SetParameterValue(key, $(obj).val(), url);
    });

    return url;
}

function SetSportTypeParams(url) {

    $("input.sportfilter").each(function (index, obj) {
        url = SetParameterValue($(obj).attr("id"), $(obj).is(":checked"), url);
    });

    return url;
}

function SetDefaultSportTypeParams(url) {
    url = SetParameterValue("showsb", 1, url);
    url = SetParameterValue("showrb", 1, url);
    url = SetParameterValue("showng", 1, url);
    url = SetParameterValue("showba", 1, url);
    url = SetParameterValue("showlc", 1, url);

    return url;
}


function SetCustomSportTypeParams(url, showsb, showrb, showng, showba, showlc) {
    url = SetParameterValue("showsb", showsb, url);
    url = SetParameterValue("showrb", showrb, url);
    url = SetParameterValue("showng", showng, url);
    url = SetParameterValue("showba", showba, url);
    url = SetParameterValue("showlc", showlc, url);

    return url;
}

function InitExcelFunction() {
    var exportExcelImg = $("#exporttoexcel");
    var mainForm = document.forms[0];
    if (exportExcelImg && mainForm) {

        exportExcelImg.onblur = function () {
            $("#exporttoexcel").focused = false;
        }
        exportExcelImg.onfocus = function () {
            $("#exporttoexcel").focused = true;
        }

        mainForm.onkeypress = function (evt) {
            var keyPressEvent = evt ? evt : window.event;
            if (keyPressEvent.keyCode == 13) {
                var src = keyPressEvent.srcElement || keyPressEvent.target;
                if (!src || (src.tagName.toLowerCase() != "textarea")) {
                    if (!$("#exporttoexcel").focused) {
                        if (keyPressEvent.stopPropagation) keyPressEvent.stopPropagation();
                        return false;
                    }
                }
            }
            return true;
        }
    }
}


function BlockContent() {
    var loadingUrl = ibc.GetBaseUrl() + "_GlobalResources/Images/loader.gif";
    var divLoading = "<div style='width: 100px; height: 100px; background: url(" + loadingUrl + ") no-repeat center'></div>";
    //block content
    if (parent.frames["main"]
        && parent.frames["main"].$
        && parent.frames["main"].$.blockUI) {

        parent.frames["main"].$.blockUI({
            css: { background: 'transparent', border: 'none' },
            overlayCSS: { backgroundColor: '#FFF', opacity: '0.7', filter: 'alpha(opacity=70)' },
            message: $(divLoading), timeout: 120000
        });
    }
}

function UnBlockContent() {
    if (parent.frames["main"]
        && parent.frames["main"].$
        && parent.frames["main"].$.blockUI) {

        parent.frames["main"].$.unblockUI();
    }
}


function BlockUiAndGoToUrl(url) {
    if (url != undefined && url.length > 0) {
        BlockContent();
        window.location.href = url;
    }
}

function BlockUIFrames(frameId) {

    if (parent.frames[frameId] != undefined) {
        parent.frames[frameId].$.blockUI({
            css: { background: 'transparent', border: 'none' },
            overlayCSS: { backgroundColor: '#FFF', opacity: '0.7', filter: 'alpha(opacity=70)' },
            message: "", timeout: 120000
        });
    }
}

function UnblockUIFrames() {
    if (parent.frames.length <= 0) return;
    for (var i = 0; i < 2; i++) {
        if (parent.frames[i] != undefined
            && parent.frames[i].$
            && parent.frames[i].$.unblockUI) {
            parent.frames[i].$.unblockUI(); // unblock UI frames
        }
    }
}

$(window).load(function () {
    _startup();
    inc(ibc.GetBaseUrl() + "_GlobalResources/Js/lib/jquery.blockui.js?v=2013.11.3.1");
    InitExcelFunction();
    // Block UI if any button is clicked
    $(".blockui").bind("click", function () {
        BlockContent();
    });

    if (jQuery().cookie) {
        $.cookie("LicenseeType", null, { expires: -10, path: '/' });
        $.cookie("CurrencyId", null, { expires: -10, path: '/' });
        $.cookie("CurrencyId", null, { expires: -10, path: '/' });
    }

    // Remove useless cookies
});

/*@Alex20110615*/
/*StringBuilder Function*/
StringBuilder = function (initialText) {
    var _parts = new Array();
    if (initialText) _parts.append(initialText);
    this.append = function (text) {
        if (text) _parts.push(text);
    }
    this.appendLine = function (text) {
        this.append(text);
        this.append("\r\n");
    }
    this.clear = function () {
        _parts.clear();
    }
    this.isEmpty = function () {
        return (_parts.length == 0);
    }
    this.toString = function (delimiter) {
        delimiter = delimiter || '';
        return _parts.join(delimiter);
    }
}

// Bold check
