﻿function ChangePassword() {
    // Validate password
    var txtOldPwd = $('#txtOldPwd').val();
    var txtNewPwd = $('#txtNewPwd').val();
    var txtConfirmPwd = $('#txtConfirmPwd').val();

    if (txtOldPwd.length == 0) {
        errMsg = _page.alertInputOldPwd;

        $('#txtOldPwd').focus();
    }
    else if (txtNewPwd != txtConfirmPwd) {
        errMsg = _page.alertErrorConfirm;
        $('#txtNewPwd').focus();
    }
    else {
        errMsg = ValidatePassword(txtNewPwd);
        $('#txtNewPwd').focus();
    }

    if (null != errMsg) {
        ibcMsg.Show(errMsg);
        return;
    }


    ibc.Lock(false);


    $.ajax({
        url: "ChangePass.ashx",
        data: ({ txtNewPwd: $('#txtNewPwd').val(),
            txtOldPwd: $('#txtOldPwd').val(),
            txtConfirmPwd: $('#txtConfirmPwd').val()}),
        dataType: "json",
        type: "POST",
        async: false,
        success: function(result) {
            ibc.UnLock();
            // Post with return result in JSON format
            var errCode = result.errCode;
            if (errCode == 0) {
                ibcMsg.Show(_page.alertPasswordSucc, true);
                if (_page.firstLogged) {
                    setTimeout('ibc.Refresh()', 2000);
                }
            }
            else {
                $('#txtOldPwd').focus();
                ibcMsg.Show(result.errMsg);
            }
        }
    });
}

function Reset() {
    $('#txtOldPwd').val("");
    $('#txtNewPwd').val("");
    $('#txtConfirmPwd').val("");
}


// Check pass call in keyup event
function CheckPass(pwdElement, iconElementId) {
    var isPwd = IsPassWord(pwdElement.value);
    var iconElement = $(iconElementId);

    if (!iconElement) return false;

    if (isPwd) {
        iconElement.className = 'PwdSuccess';
    }
    else {
        iconElement.className = 'PwdError';
    }

    return isPwd;
}

function ValidatePassword(str) {
    if (str.length == 0) return _page.alertPasswordEmpty;
    else if (!IsPassWord(str)) return _page.alertPasswordRequire;

    return null;
}

$(window).load(function() {
    if ($("#header-title")) {//Set title page
        parent.document.title = document.title;
    }
});