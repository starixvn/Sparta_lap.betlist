﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="SSODenyAccess.aspx.cs" Inherits="SSODenyAccess" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <center>
        <div>
            <h2 style="color:Red;">
           <asp:Literal ID="LiteralDenyLogin" runat="server"></asp:Literal>
            </h2>
        </div>
    </center>
    </form>
</body>
</html>
