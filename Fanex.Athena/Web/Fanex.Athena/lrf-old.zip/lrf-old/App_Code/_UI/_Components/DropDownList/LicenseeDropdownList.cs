﻿using System.Web;
using Fanex.Athena.Service.Implement.Users;
using Fanex.Athena.Service.Interface.Users;

namespace Olympus.LRF.UI._Components.DropDownList
{
    /// <summary>
    /// Summary description for LicenseeDropdownList
    /// </summary>
    public class LicenseeDropdownList : DropDownList
    {
        private readonly ISessionService _sessionService = new SessionService();
        private readonly ILicenseeService _licenseeService = new LicenseeService();
        public LicenseeDropdownList()
        {
            OnChangeFunction = "ChangeLicenses();";
        }

        public LicenseeDropdownList(string onChangeFunc)
        {
            OnChangeFunction = onChangeFunc;
        }


        public override string SelectedValue
        {
            get
            {
                if (HttpContext.Current != null
                    && !string.IsNullOrEmpty(HttpContext.Current.Request[ID]))
                {
                    return HttpContext.Current.Request[ID];
                }
                return this._sessionService.LicenseeSession.LicenseeId.ToString();
            }
        }

        protected override void Render()
        {
            ID = "ddlLicensee";

            IsRendered = true;
            Template.ID = ID;
            Template.OnChangeFunc = OnChangeFunction;
            Template.Option.Clear();
            var currentSession = _sessionService.UserSession;
            var licenseeList = _licenseeService.GetByUser(currentSession.UserId);

            string selectedLicenseeId = SelectedValue;
            if (null != licenseeList && licenseeList.Count > 0)
            {
                var ddlLicensee = new DropDownList_Option_Block();
                var entityList = licenseeList;
                Template.OnChangeFunc = OnChangeFunction;
                foreach (var licensee in entityList)
                {
                    ddlLicensee.ValueField = licensee.Id.ToString();
                    ddlLicensee.TextField = licensee.Name;
                    ddlLicensee.Selected = (selectedLicenseeId == ddlLicensee.ValueField)
                                               ? "selected='selected'"
                                               : string.Empty;

                    Template.Option.Append(ddlLicensee);
                }

                // Template.SelectedId = selectedLicenseeId;
            }
        }

        # region String Convertion

        public static implicit operator string(LicenseeDropdownList value)
        {
            return value.ToString();
        }

        public override string ToString()
        {
            if (!IsRendered) Render();

            return Template.ToString();
        }

        #endregion
    }
}