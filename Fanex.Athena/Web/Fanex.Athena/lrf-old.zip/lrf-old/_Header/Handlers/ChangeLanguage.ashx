﻿<%@ WebHandler Language="C#" Class="ChangeLanguage" %>

using System;
using System.Web;
using System.Web.SessionState;
public class ChangeLanguage : IHttpHandler, IRequiresSessionState
{

    public void ProcessRequest(HttpContext context)
    {
        context.Response.ContentType = "text/plain";
        var languageCode = context.Request.QueryString["languagesite"];
        var changed = false;
        if (languageCode != null && !string.IsNullOrEmpty(languageCode))
        {
            languageCode = languageCode.Trim();
            if (Fanex.Athena.Extension.Utility.Util.IsValidLanguage(languageCode))
            {
                var langService = new Fanex.Athena.Service.Implement.Common.LanguageService();
                var currentLang = langService.GetCurrentLanguage();
                if (!currentLang.Equals(languageCode))
                {
                    changed = langService.ChangeLanguage(languageCode);
                }
            }
        }

        if (changed)
        {
            context.Response.Write("1");
        }
        else
        {
            context.Response.Write("0");
        }

    }

    public bool IsReusable
    {
        get
        {
            return false;
        }
    }

}
