﻿using System.Collections;
using System.Web;
using System.Web.SessionState;
using IBC.Agent.UI._Base;

/*
 * Created 20091211@Lee - Base ashx page, use Template method pattern http://sourcemaking.com/design_patterns/template_method
 * Revision: 
 * 20091211@Lee - Initializing
 * 20100227@Lee - Update security: validating http input
 * 
 * !!!CAUTION: ANY REVISION MUST BE APPROVED BEFORE PROCEEDING!!!
 * 
 */

namespace Olympus.LRF.UI._Base
{
    /// <summary>
    /// Implement IHttpHandler, process request and return in JSON format.
    /// All ashx must be inherited form this handler.
    /// </summary>
    public abstract class TplHandler : TplBase, IHttpHandler, IRequiresSessionState
    {
        protected bool IsValidateRequest = true;
        private HttpContext _Context;

        /// <summary>
        /// LicenseeWinlossList of returning results.
        /// </summary>
        private JSONData _Result = new JSONData(10);

        public new HttpResponse Response
        {
            get { return _Context.Response; }
        }

        public new HttpRequest Request
        {
            get { return _Context.Request; }
        }

        #region IHttpHandler Members

        public new bool IsReusable
        {
            get { return true; }
        }

        public new void ProcessRequest(HttpContext context)
        {
            _Context = context;
            // Check potentially dangerous request
            try
            {
                if (IsValidateRequest) context.Request.ValidateInput();

                // Process requested param
                Parameters = new Hashtable();
                ProcessRequest(ref Parameters);
            }
            catch (HttpRequestValidationException e)
            {
                var error = new Result(e.ErrorCode, "Invalid parameter value.");
                _Result.AsResult(error);
                Response.Write(JSON.Render(_Result));
                return;
            }

            context.Response.Cache.SetCacheability(HttpCacheability.NoCache);

            // ContentType always be json
            context.Response.ContentType = "text/plain";

            // Validate request
            object obj = ValidateRequest(Parameters);

            // Return error
            if (null != obj)
            {
                var result = obj as Result ?? new Result(ErrorType.Unknown, obj as string);

                _Result.AsResult(result);
            }
            else
            {
                // Doing data5m5
                View = InvokeData(Parameters);

                // Render result
                RenderResult(ref _Result);
            }

            Response.Write(JSON.Render(_Result));

            // End
        }

        #endregion

        /// <summary>
        /// Process and return a list of result.
        /// </summary>
        /// <returns></returns>
        public abstract void RenderResult(ref JSONData data);
    }
}