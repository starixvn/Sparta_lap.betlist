﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using JSoft.Utility;
using LiveCasinoLibrary.SBAgent;

public partial class LiveGenHistoryImg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string strGameType = StringUtil.CStr(Request["GameType"]); //遊戲分類

        var objHistoryImg = new GenHistoryImage();

        switch (strGameType)
        {
            case "B0001": //Bingo
                objHistoryImg.GenResultBingo(this.Context);
                break;
            default:
                break;
        }
       
    }
}
