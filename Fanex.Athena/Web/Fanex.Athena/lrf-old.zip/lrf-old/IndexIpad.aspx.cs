﻿using System;
using System.Web.UI;
using Fanex.Athena.Service.Interface.Users;
using Fanex.Athena.Service.Implement.Users;

public partial class Index : BasePage
{
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        var _sessionService = new SessionService();
        var user = _sessionService.UserSession;
        if (user == null || user.UserId <= 0
            || string.IsNullOrEmpty(user.UserName))
        {
            LicenseeHelper.RedirectToSigninPage();
        }
    }
    
    
}