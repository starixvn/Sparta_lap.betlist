﻿/*
* Created 20100203@Lee - Left menu page functions
* Revision ?@? - ... 
* 
*/
function menuItemSelect(id, source) {

    $('td.active-menu').removeClass('active-menu');
    $('#child-menu-' + id).addClass('active-menu');
    $("#ActiveLinkIdOriginal").val('child-menu-link-' + id);

    var parentTag = $('#child-menu-link-' + id).closest('table');
    var prevTag = parentTag.prev('div');
    var parentMenu = prevTag.text();

    parentMenu = parentMenu.toLowerCase().replace(/\b[a-z]/g, function (letter) {
        return letter.toUpperCase();
    });

    parent.document.title = 'LRF' + ' - ' + parentMenu + ' - ' + $('#child-menu-link-' + id).html();
    return false;
}

function menuToggle(id) {

    var hideSubMenu = $('#children-menu-' + id).is(':hidden');

    //hide other menu
    $.each($('#menu-container table[id^="children-menu-"]'), function (index, value) {
        if ($(this).attr("id") == 'children-menu-' + id) {
            if (hideSubMenu) {
                $('#children-menu-' + id).slideDown("fast");
            }
            else {
                $('#children-menu-' + id).slideUp("fast");
            }
        }
        else {
            var ie7 = (typeof document.addEventListener != 'function' && window.XMLHttpRequest) ? true : false;
            if (ie7) {
                $(this).hide();
            }
            else {
                $(this).slideUp("fast");
            }

            $('#menu-arrow-' + id).attr("class", "parent-menu-collapse");
        }
    });

    //change arrow icon for menu title
    var arrowClass = hideSubMenu ? 'parent-menu-open' : 'parent-menu-collapse';
    var bgClass = hideSubMenu ? "parent-menu-open2" : "parent-menu-collapse2";
    $('#menu-arrow-' + id).attr('class', arrowClass);
    $("#menu-title-" + id).parent().attr('class', bgClass);

}

function onclickUser(username) {

    var txtUserName = $('#txtUserName');
    if (txtUserName.val() == username) {
        txtUserName.removeClass("search-text");
        txtUserName.addClass("text-focus");
        txtUserName.val('');
    }
};

function onblurUser(username) {

    var txtUserName = $('#txtUserName');
    if (txtUserName.val() == '') {
        txtUserName.removeClass("text-focus");
        txtUserName.addClass("search-text");
        txtUserName.val(username);
    }
};

function KeyPress(e) {

    if (!e) e = window.event;
    var key = (e.keyCode) ? e.keyCode : e.which;
    if (key == 13) {
        searchByUserName();
        return false;
    }
};

function searchByUserName() {

    //ref Core.js
    BlockContent();

    var userName = $('#txtUserName').val();
    userName = null == userName ? "" : userName;

    var url = "../Customer/CustomerList";
    url = SetParameterValue('userName', userName, url);

    //active menu memberinformation
    var tdCustomerList = $('#MemberInfoCustomerList').closest('td');
    if (tdCustomerList.hasClass('active-menu') == false) {
        //remove previous active menu
        $('td').removeClass('active-menu');
        tdCustomerList.addClass('active-menu');
        $('.sub-menu-container').hide();
        $('#aMemberInfo').trigger("mousedown");
    }
    top.main.location.href = url;
}

function activeDefaultLink() {
    var found = false;

    $.each($('div#menu-container a[id^="child-menu-link"]'), function (index, value) {
        if (found) return;

        var link = $(value);
        if (link.prop('id') == "child-menu-link-42") {
            found = true;

            $('td.active-menu').removeClass('active-menu');
            link.closest("td").addClass('active-menu');
            link.closest("table").show();
        }
    });
}

$(window).load(function () {

    // auto suggest username
    var txtUserName = $('#txtUserName');
    var serUrl = "../CustomerAPI/SearchCustomer?licenseeType=&currencyId=0";

    txtUserName.autocomplete({ serviceUrl: serUrl, minChars: 2 });
    $("#search-button").click(function () { return searchByUserName(); });

    activeDefaultLink();
});
