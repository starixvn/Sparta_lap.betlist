﻿<%@ Page Language="C#" AutoEventWireup="true" ValidateRequest="false" CodeFile="LocationRestriction.aspx.cs"
    Inherits="LocationRestriction" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>LRF - <%#Fanex.Athena.Models.ViewModel.ViewResources.LocationRestriction %></title>
    <link href="../Content/Authorization/SignIn.css" rel="stylesheet" type="text/css" />
    <script type="text/ecmascript">
        var index = window;
        while (index != index.parent) // Jump out
        {
            index = index.parent;
        }

        var currentLocation = index.location.href.toLowerCase();
        var isSigninPage = currentLocation.indexOf("locationrestriction.aspx") >= 0 || currentLocation.indexOf("signin.aspx") >= 0;

        if (!isSigninPage) {
            index.location.href = location.href;
        }

    </script>
</head>
<body>
    <div class="message-content">
        <div class="restriction-header">
        </div>
        <div class="message-content-bg">
            <p>
            <%=string.Format(Fanex.Athena.Models.ViewModel.ViewResources.LocationRestrictionMsg,"<b style=\"color: Red\">CS ONEONONE </b>(<a href=\"mailto:cs@oneonone-solutions.com\"><b>cs@oneonone-solutions.com</b></a>)") %>
            </p>
        </div>
        <div class="message-content-bottom">
        </div>
    </div>
</body>
</html>
