﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

/*
 * Created 20091211@Lee - JSON processing
 * Revision: 
 * 20091211@Lee - Initializing
 * 
 * !!!CAUTION: ANY REVISION MUST BE APPROVED BEFORE PROCEEDING!!!
 * 
 */

namespace Olympus.LRF.UI._Base
{
    public static class JSON
    {
        /// <summary>
        /// Convert a list of DictionaryEntry to JSON format.
        /// </summary>
        /// <param name="d"></param>
        /// <returns></returns>
        public static string Render(JSONData d)
        {
            if (null == d) return "null";
            var c = d.Count;

            var builder = new StringBuilder();
            builder.Append('{');


            for (var i = 0; i < c; i++)
            {
                builder.Append(ObjectToJSON(d[i].Key, d[i].Value));
                if (i < c - 1) builder.Append(',');
            }

            builder.Append('}');
            return builder.ToString();
        }

        /// <summary>
        /// Declare an object as JSON format.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        private static string ObjectToJSON(object name, object value)
        {
            if (null == name) return null;
            return "\"" + name + "\":" + ToJSON(value);
        }

        /// <summary>
        /// Convert an object to JSON format.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private static string ToJSON(object value)
        {
            if (null == value) return "null";

            Type type = value.GetType();
            string text = value.ToString();

            if (typeof (string) == type)
                return FormatString(text);
            if (typeof (JSONData) == type)
                return Render((JSONData) (value));
            if (typeof (bool) == type)
                return text.ToLower();

            return type.IsArray ? ArrayToJSON(value as Array) : text;

            // Return default ToString() method
        }

        private static string FormatString(string text)
        {
            return "\"" + text.Replace("\"", "\\\"") + "\"";
        }

        private static string ArrayToJSON(Array values)
        {
            if (null == values) return "null";
            int c = values.Length;

            var builder = new StringBuilder();
            builder.Append('[');

            for (int i = 0; i < c; i++)
            {
                builder.Append(ToJSON(values.GetValue(i)));
                if (i < c - 1) builder.Append(',');
            }

            builder.Append(']');
            return builder.ToString();
        }
    }

    /// <summary>
    /// Represent .net data in JSON format.
    /// </summary>
    public class JSONData : List<DictionaryEntry>
    {
        public JSONData()
        {
        }

        public JSONData(int capacity)
        {
            Capacity = capacity;
        }

        public void Add(object name, object value)
        {
            Add(new DictionaryEntry(name, value));
        }

        /// <summary>
        /// Return an error.
        /// </summary>
        /// <param name="errCode"></param>
        /// <param name="errMsg"></param>
        public void AsError(int errCode, string errMsg)
        {
            Clear();
            Add(new DictionaryEntry(JSONError.ErrorCode, errCode));
            Add(new DictionaryEntry(JSONError.ErrorMsg, errMsg));
        }

        /// <summary>
        /// Return an error.
        /// </summary>
        /// <param name="errType"></param>
        /// <param name="errMsg"></param>
        public void AsError(ErrorType errType, string errMsg)
        {
            Clear();
            Add(new DictionaryEntry(JSONError.ErrorCode, (int) (errType)));
            Add(new DictionaryEntry(JSONError.ErrorMsg, errMsg));
        }

        /// <summary>
        /// Return a result.
        /// </summary>
        public void AsResult(Result r)
        {
            Clear();
            Add(new DictionaryEntry(JSONError.ErrorCode, r.ErrCode));
            if (r.ErrCode != 0)
            {
                Add(new DictionaryEntry(JSONError.ErrorMsg, r.ErrMsg));
            }
        }

        /// <summary>
        /// Return a success result.
        /// </summary>
        public void AsSuccessResult()
        {
            Clear();
            Add(new DictionaryEntry(JSONError.ErrorCode, (int) (ErrorType.Success)));
        }
    }
}