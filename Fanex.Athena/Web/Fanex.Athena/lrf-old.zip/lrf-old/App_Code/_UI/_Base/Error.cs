﻿/*
 * Created 20091211@Lee - ERROR object in UI
 * Revision: 
 * 20091211@Lee - Initializing
 * 
 * !!!CAUTION: ANY REVISION MUST BE APPROVED BEFORE PROCEEDING!!!
 * 
 */

namespace Olympus.LRF.UI._Base
{
    public class JSONError : JSONData
    {
        //Error code convention:
        //-1	Unknown error
        //0	Success
        //> 0	Error code, retrieve error message from errMsg field
        public const string ErrorCode = "errCode";
        public const string ErrorMsg = "errMsg";
        public const string ErrorData = "data";

        public JSONError(int errorCode, string errorMsg)
        {
            Add(ErrorCode, errorCode);
            Add(ErrorMsg, errorMsg);
        }

        public JSONError(ErrorType errorType, string errorMsg)
        {
            Add(ErrorCode, (int) (errorType));
            Add(ErrorMsg, errorMsg);
        }
    }

    public enum ErrorType
    {
        Success = 0,
        Unknown = -1,
        AccessDenied = 1,
        AccountClosed = 2,
        KickedOut = 3,
        UnderMaintenance = 4,
        SessionOverride
    }

    public class Result
    {
        public int ErrCode;
        public string ErrMsg;

        public Result(int code, string msg)
        {
            ErrCode = code;
            ErrMsg = msg;
        }

        public Result(ErrorType type, string msg)
        {
            ErrCode = (int) (type);
            ErrMsg = msg;
        }
    }
}