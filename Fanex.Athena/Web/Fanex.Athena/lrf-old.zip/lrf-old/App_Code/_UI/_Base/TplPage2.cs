﻿using System.Collections;
using System.Web.UI;

/*
 * Created 20091211@Lee - Base aspx page, use Template method pattern http://sourcemaking.com/design_patterns/template_method
 * Revision: 
 * 20091211@Lee - Initializing
 * 
 * !!!CAUTION: ANY REVISION MUST BE APPROVED BEFORE PROCEEDING!!!
 * 
 */

namespace IBC.Agent.UI._Base
{
    /// <summary>
    /// Use this class only when need to handle post back event.
    /// </summary>
    public abstract class TplPage2 : TplPage
    {
        /// <summary>
        /// New IsPostBack.
        /// </summary>
        public new bool IsPostBack
        {
            get { return Request.Form.Count > 0; }
        }

        /// <summary>
        /// Processing post back event. It was called before any routine. Do process it and redirect to dedicated page.
        /// </summary>
        public abstract void OnPostBack();

        /// <summary>
        /// Don't override this method in instance class.
        /// </summary>
        /// <param name="writer"></param>
        protected override void Render(HtmlTextWriter writer)
        {
            if (IsPostBack)
            {
                OnPostBack();
            }

            Parameters = new Hashtable();

            ProcessRequest(ref Parameters);

            object error = ValidateRequest(Parameters);

            if (null != error)
            {
                writer.Write(error);
            }
            else
            {
                View = InvokeData(Parameters);
                RenderContent(writer);
            }

            // Render javascript variables
            WriteJavascriptObjects(writer);
        }
    }
}