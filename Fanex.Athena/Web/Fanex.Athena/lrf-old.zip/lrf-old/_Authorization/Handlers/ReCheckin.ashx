﻿<%@ WebHandler Language="C#" Class="Olympus.LRF.UI._Authorization.ReCheckin_Handler" %>

using System.Collections;
using Olympus.LRF.UI._Base;
using Fanex.Athena.Service.Interface.Users;
using Fanex.Athena.Service.Implement.Configuration;
using Fanex.Athena.Service.Interface.Configuration;
using Fanex.Athena.Models.ViewModel;

/*
 * Created 20100126@Lee - Recheck-in handler. Keep session alive by interval request check in On_User database server.
 * Revision:
 * ?@? - ... 
 * 
 */

namespace Olympus.LRF.UI._Authorization
{
    public class ReCheckin_Handler : TplHandler
    {
        private IMaintenanceService _maintenanceService = new MaintenanceService();

        public override void ProcessRequest(ref Hashtable p)
        {

        }

        public override object ValidateRequest(Hashtable p)
        {
            int onId = 0;
            int.TryParse(Request["onid"], out onId);

            // Invalid re-check-in
            if (onId == 0 || !Request.IsAuthenticated || _sessionService.UserSession == null)
            {
                return new Result(ErrorType.AccessDenied, ViewResources.AccessDeniedMsg);
            }

            if (onId != _sessionService.UserSession.OnUserId)
            {
                return new Result(ErrorType.SessionOverride,  ViewResources.SessionLoggedMsg);
            }

            var maintenanceInfo = _maintenanceService.MaintenanceInfo;
            var message = string.Format(ViewResources.UndermaintenanceMsg, maintenanceInfo.UmTimeFrom, maintenanceInfo.UmTimeTo);
            return maintenanceInfo.IsDownTime ? new Result(ErrorType.AccessDenied, message) : null;
        }

        public override object InvokeData(Hashtable p)
        {
            string errMsg = null;
            IUserService userService = new Fanex.Athena.Service.Implement.Users.UserService();
            bool isSuccess = !userService.ReCheckin(_sessionService.UserSession.OnUserId);

            int errCode = isSuccess ? 0 : (int)(ErrorType.KickedOut);
            errMsg = isSuccess ? _sessionService.LicenseeSession.LicenseeId.ToString() : ViewResources.SessionLoggedMsg;

            return new Result(errCode, errMsg);
        }

        public override void RenderResult(ref JSONData data)
        {
            var r = View as Result;
            data.Clear();
            data.Add(new DictionaryEntry(JSONError.ErrorCode, r.ErrCode));
            data.Add(new DictionaryEntry(JSONError.ErrorMsg, r.ErrMsg));
        }

        private bool IsUserAuthenticated()
        {
            var isAuthenticated = User != null
                && User.Identity != null
                && User.Identity.IsAuthenticated
                && Request.IsAuthenticated;

            var isSessionValid = _sessionService.UserSession != null
                && _sessionService.UserSession.UserId > 0
                && _sessionService.LicenseeSession != null
                && _sessionService.LicenseeSession.LicenseeId > 0;

            return isAuthenticated && isSessionValid;
        }
    }
}

