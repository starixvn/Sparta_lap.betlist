﻿<%@ WebHandler Language="C#" Class="Olympus.LRF.UI._Authorization.SignOut_Handler" %>

using System.Collections;
using System.Web.Security;
using Olympus.LRF.UI._Base;
using Fanex.Athena.Service.Interface.Users;
using Fanex.Athena.Service.Implement.Users;

/*
 * Created 20100126@Lee - Sign-out handler. Clear all session keys, cookies, check-out On_User database server.
 * Revision:
 * ?@? - ... 
 * 
 */

namespace Olympus.LRF.UI._Authorization
{
    public class SignOut_Handler : TplHandler
    {
        public override void ProcessRequest(ref Hashtable p)
        {
            // No requested parameters
        }

        public override object ValidateRequest(Hashtable p)
        {
            return null;
        }

        public override object InvokeData(Hashtable p)
        {
            // Kick-out
            IUserService userService = new UserService();
            if (_sessionService.UserSession != null)
            {
                userService.Logout(_sessionService.UserSession.OnUserId);
            }
            return null;
        }

        public override void RenderResult(ref JSONData data)
        {
            Session.Clear();
            ClearCookies();
            FormsAuthentication.SignOut();
            FormsAuthentication.RedirectToLoginPage();
        }

        private void ClearCookies()
        {
            var cookieList = this.Context.Response.Cookies;
            var cookieNameList = this.Context.Response.Cookies.AllKeys;
            foreach (var name in cookieNameList)
            {
                if (Request.Cookies[name] == null)
                {
                    continue;
                }

                var cookie = new System.Web.HttpCookie(name);
                cookie.Expires = System.DateTime.Now.AddDays(-1d);
                Response.Cookies.Add(cookie);
            }
        }
    }
}