﻿namespace Olympus.LRF.UI._Base
Assembly will be Olympus.LRF.UI._Base.dll

This namespace contain basic processing for UI tier, such as JSON, Extension for UI, IBasePage, TplPage, TplHandler...
Use Template method pattern http://sourcemaking.com/design_patterns/template_method