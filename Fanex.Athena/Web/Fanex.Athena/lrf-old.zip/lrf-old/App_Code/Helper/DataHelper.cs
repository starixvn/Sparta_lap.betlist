﻿using System;


public static class DataHelper
{
    public const int MAX_PAGE_SIZE = 10000000;

    /// <summary>
    /// Get DB boolean value
    /// If null, return false
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    public static bool GetDBBooleanValue(object data)
    {
        if (Convert.IsDBNull(data)) return false;
        return (bool) data;
    }

    /// <summary>
    /// Get int value from database
    /// return 0 if the object is DBNull
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    public static int GetDBIntValue(object data)
    {
        if (Convert.IsDBNull(data)) return 0;
        return (int) data;
    }

    /// <summary>
    /// Get decimal value from database
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    public static decimal GetDBDecimalValue(object data)
    {
        if (Convert.IsDBNull(data)) return 0;
        return (decimal) data;
    }

    /// <summary>
    /// Get string value from database
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    public static string GetDBStringValue(object data)
    {
        if (Convert.IsDBNull(data)) return string.Empty;
        return data.ToString();
    }
}