<%@ Page Language="C#" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<script runat="server">
    public void Button2_ServerClick(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(tplName.Value))
            return;
        DNAide.Web.TemplateHandler.RemoveTemplate(tplName.Value);
        msg.Text = "Template removed";
    }
    public void Button1_ServerClick(object sender, EventArgs e)
    {
        tplName.Value = "";
        DNAide.Web.TemplateHandler.ClearTemplates();
        msg.Text = "Template cache cleared";
    }
</script>

<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Template Mananger</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        Template/Aspx file name (template-folder is not neccessary for template file name)<br />
        <input type="text" size="50" runat="server" id="tplName" />
        <input type="button" value="Remove Template" runat="server" id="Button2" onserverclick="Button2_ServerClick" />
        <input id="Button1" type="button" value="Clear all Template" runat="server" onserverclick="Button1_ServerClick" />
        <br />
        <asp:Label runat="server" ID="msg" ForeColor="red"></asp:Label>
    </div>
    </form>
</body>
</html>
