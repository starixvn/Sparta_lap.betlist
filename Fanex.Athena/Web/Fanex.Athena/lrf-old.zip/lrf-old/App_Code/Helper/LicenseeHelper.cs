﻿// ----------------------------------------------------------------------
// <copyright file="LicenseeHelper.cs" company="Sunplus Vietnam IT">
//     Copyright (c) LRF. All rights reserved
// </copyright>
// ------------------------------------------------------------------------

using System.Linq;
using System.Web;
using System.Web.Security;
using Fanex.Athena.Service.Implement.Users;
using Fanex.Athena.Service.Interface.Users;


/// <summary>
/// Helper to process all licensee params
/// </summary>
public static class LicenseeHelper
{
    private static ISessionService _sessionService = new SessionService();
    public static string RootPath
    {
        get { return VirtualPathUtility.ToAbsolute("~/"); }
    }

    #region Request Helper


    /// <summary>
    /// Get selected licensee id
    /// If the selected licensee is invalid, it doesn't belong to the logged-in user, logout
    /// </summary>
    /// <returns>
    /// Returns requested licenseeId
    /// </returns>
    public static int GetRequestLicenseeId()
    {
        int licenseeId;
        int.TryParse(HttpContext.Current.Request["LicenseeId"], out licenseeId);

        var currentUser = _sessionService.UserSession;
        var licenseeService = new LicenseeService();
        var licenseeList = licenseeService.GetByUser(currentUser.UserId);

        //Find licensee
        var requestedLicenseeList = licenseeList
            .Where(licensee => licensee.Id == licenseeId).ToList();

        // Validate the request licensee id
        licenseeId = requestedLicenseeList.Count > 0 ? licenseeId : 0;

        // Get default licensee if request licensee id is invalid       
        licenseeId = licenseeId > 0
                         ? licenseeId
                         : licenseeList.FirstOrDefault().Id;

        if (licenseeId > 0)
        {

            return licenseeId;
        }

        RedirectToSigninPage();
        return 0;
    }

    #endregion

    #region Redirect Helper

    /// <summary>
    /// Use this function when logout or user session is invalid
    /// Clear session
    /// Redirect to signin page
    /// </summary>
    public static void RedirectToSigninPage()
    {
        if (HttpContext.Current != null)
        {
            HttpContext.Current.Session.Clear();
            HttpContext.Current.Session.Abandon();
            HttpContext.Current.Response.Redirect(FormsAuthentication.LoginUrl);
        }
    }

    #endregion


    #region SSO

    public static bool IsInternalLogin
    {
        get { return _sessionService.UserSession.IsInternal; }
    }

    #endregion

    #region Internal Admin Authorization

    /// <summary>
    /// Transfer to Access deny if current user is internal user
    /// Use this function in every page which internal user does not
    /// have permission such as Add new account, reset password ...
    /// </summary>
    public static void InternalAccessRestriction()
    {
        if (_sessionService.UserSession.IsInternal)
        {
            HttpContext.Current.Server.Transfer("~/AccessDenied.aspx");
        }
    }

    /// <summary>
    /// Use this function to make sure following things
    /// Do not allow user edit himself/herself
    /// Do not allow admin user edit internal user
    /// Do not allow internal user edit admin user
    /// </summary>
    /// <param name="editingUserId"></param>
    public static void EditUserRestriction(int editingUserId)
    {
        var currentUser = _sessionService.UserSession;

        var userService = new UserService();
        var editingUser = userService.GetUserInfo(_sessionService.LicenseeSession.LicenseeId, editingUserId);

        if (currentUser.UserId == editingUserId || editingUser == null || editingUser.IsInternal != currentUser.IsInternal)
        {
            HttpContext.Current.Server.Transfer("~/AccessDenied.aspx");
        }
    }

    /// <summary>
    /// Do not allow user edit himself/herself
    /// Do not allow internal user edit admin user permission
    /// </summary>
    public static void EditUserPermissionRestriction(int editingUserId)
    {
        var currentUser = _sessionService.UserSession;

        if (currentUser.UserId == editingUserId)
        {
            HttpContext.Current.Server.Transfer("~/AccessDenied.aspx");
        }

        if (!currentUser.IsInternal)
        {
            return;
        }

        var userService = new UserService();
        var editingUser = userService.GetUserInfo(_sessionService.LicenseeSession.LicenseeId, editingUserId);

        if (editingUser == null || !editingUser.IsInternal)
        {
            HttpContext.Current.Server.Transfer("~/AccessDenied.aspx");
        }
    }

    #endregion
}
