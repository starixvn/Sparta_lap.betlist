﻿using System.Collections;
using System.Web.UI;
using Olympus.LRF.UI._Base;

/*
 * Created 20091211@Lee - Base aspx page, use Template method pattern http://sourcemaking.com/design_patterns/template_method
 * Revision: 
 * 20091211@Lee - Initializing
 * 
 * !!!CAUTION: ANY REVISION MUST BE APPROVED BEFORE PROCEEDING!!!
 * 
 */

namespace IBC.Agent.UI._Base
{
    public abstract class TplPage : TplBase
    {


        /// <summary>
        /// Root namespace of json data returned.
        /// </summary>
        private const string JsData = "_page";

        /// <summary>
        /// LicenseeWinlossList of values will be rendered to browser as JSON format.
        /// </summary>
        private readonly JSONData _jsData = new JSONData(10);

        /// <summary>
        /// Register an object as JSON format. Access object in client site by _page.objName.
        /// </summary>
        /// <param name="name">Name of the object.</param>
        /// <param name="value">Value of the object. It could be a JSONData object.</param>
        public void RegisterJavascriptObject(object name, object value)
        {
            _jsData.Add(name, value);
        }

        /// <summary>
        /// Register an error as JSON format.
        /// </summary>
        /// <param name="errCode"></param>
        /// <param name="errMsg"></param>
        public void RegisterJsonError(int errCode, string errMsg)
        {
            _jsData.Add(JSONError.ErrorCode, errCode);
            _jsData.Add(JSONError.ErrorMsg, errMsg);
        }

        /// <summary>
        /// Register an error as JSON format.
        /// </summary>
        /// <param name="type"></param>
        /// <param name="errMsg"></param>
        public void RegisterJsonError(ErrorType type, string errMsg)
        {
            _jsData.Add(JSONError.ErrorCode, (int)(type));
            _jsData.Add(JSONError.ErrorMsg, errMsg);
        }

        /// <summary>
        /// Render content section of html page.
        /// </summary>
        /// <param name="writer"></param>
        public abstract void RenderContent(HtmlTextWriter writer);


        /// <summary>
        /// Don't override this method in instance class.
        /// </summary>
        /// <param name="writer"></param>
        protected override void Render(HtmlTextWriter writer)
        {
            Parameters = new Hashtable();

            ProcessRequest(ref Parameters);

            object error = ValidateRequest(Parameters);

            if (null != error)
            {
                writer.Write(error);
            }
            else
            {
                if (!IsPostBack)
                {
                    View = InvokeData(Parameters);
                }
                RenderContent(writer);
            }

       
            // Render javascript variables
            WriteJavascriptObjects(writer);

        }

     
        protected void WriteJavascriptObjects(HtmlTextWriter writer)
        {
            if (0 == _jsData.Count) return;

            writer.Write("\r\n<script type=\"text/javascript\">\r\n\tvar ");
            writer.Write(JsData);
            writer.Write(" = ");
            writer.Write(JSON.Render(_jsData));
            writer.Write(";\r\n</script>");
        }
    }
}

