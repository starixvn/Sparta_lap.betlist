﻿using Fanex.Athena.Service.Implement.Common;
using Fanex.Athena.Service.Interface.Common;
/// <summary>
/// Summary description for BasePage
/// </summary>
public class BasePage : System.Web.UI.Page
{
    private ILanguageService langService = new LanguageService();
    protected override void InitializeCulture()
    {
        base.InitializeCulture();
        var currentLanguage = langService.GetCurrentLanguage();
        langService.SetPageCulture(currentLanguage);
    }
}
