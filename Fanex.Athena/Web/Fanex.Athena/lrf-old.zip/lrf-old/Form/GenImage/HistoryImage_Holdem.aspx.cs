﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using JSoft.Utility;
using HandHistoryLibrary.DataHandler.GenImage;


public partial class HistoryImage_Holdem : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        GenImage_Holdem objImg = new GenImage_Holdem();
        objImg.GenResultPic(this.Context);
    }
}
