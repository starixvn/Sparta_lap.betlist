﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ChangePass.aspx.cs" Inherits="Olympus.LRF.UI._MemberInfo.ChangePass._MemberInfo_ChangePass" %>
