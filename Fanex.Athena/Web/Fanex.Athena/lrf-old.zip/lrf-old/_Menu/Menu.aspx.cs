﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using Fanex.Athena.Extension.Utility;
using Fanex.Athena.Models.DTO.Common;
using Fanex.Athena.Service.Implement.Common;
using Fanex.Athena.Service.Interface.Common;
using Olympus.LRF.UI._Base;
using Fanex.Agent.UI._Menu;

/*
 * Created 20100126@Lee - Render left menu page
 * Revision:
 * ?@? - ... 
 * 
 */

namespace Olympus.LRF.UI._Menu
{
    public partial class Menu_Page : TplPage
    {
        private ILanguageService langService = new LanguageService();

        protected override void InitializeCulture()
        {
            base.InitializeCulture();
            langService.SetPageCulture(langService.GetCurrentLanguage());
        }
        #region Const

        protected const string MenuItemTemplate =
            "LicenseeType={0}&CurrencyId={1}&IsConvert={2}&BasedCurrencyId={3}";

        private const int _fucntionAddNewAccount = 47;

        private const int _functionCustCommGroup = 55;

        private bool _isInternalLogin;
        private bool _isAllowdCustomerCommission = false;

        private IList<Function> _userFunctionList;

        private IList<Function> _userMasterFunctionList;

        private IDictionary<int, IList<Function>> _userDetailFunctionList;


        private Menu_Template _template = new Menu_Template();

        private IFunctionService _functionManager = new FunctionService();

        #endregion

        #region Override

        public override void ProcessRequest(ref Hashtable p)
        {
            _isInternalLogin = LicenseeHelper.IsInternalLogin;
            var userFunctionIdList = _sessionService.UserSession.FunctionIdList;
            _userFunctionList = _functionManager.Functions.Where(f => userFunctionIdList.Contains(f.FunctionId))
                                                          .ToList();


            _isAllowdCustomerCommission = _sessionService.LicenseeSession.IsAllowedCustomerComm;
        }

        #endregion

        #region Events

        public override object ValidateRequest(Hashtable p)
        {
            return null;
        }

        public override object InvokeData(Hashtable p)
        {

            var excludeFunctionIdList = AppSettings.ExcludeFunctionIdList;
            _userFunctionList = _userFunctionList.Where(u => !excludeFunctionIdList.Contains(u.FunctionId))
                                                 .ToList();

            _userMasterFunctionList = _functionManager.GetMasterFunctions(_userFunctionList);
            _userDetailFunctionList = _functionManager.GetSubFunctions(_userFunctionList);

            return null;
        }

        public override void RenderContent(HtmlTextWriter writer)
        {
            // Render quick search
            RenderQuickSearch();
            RenderMenu();

            
            writer.Write(_template);
        }

        #endregion

        #region Utilities

        protected void RenderQuickSearch()
        {
            var _functionAccess = new FunctionAccessService();

            _template.CustomerQuickSearch.Visible = _functionAccess.CanManageMember;
        }

        protected void RenderMenu()
        {
            _template.MenuBlock.Clear();

            var masterFunctionList = _langService.MapWithLanguage(_functionManager.GetMasterFunctions(_userFunctionList));
            foreach (var masterFunction in masterFunctionList)
            {
                // Render menu block
                RenderMenuBlock(masterFunction);
            }


        }

        /// <summary>
        /// Render menu block
        /// </summary>
        /// <param name="masterFunction"></param>
        private void RenderMenuBlock(Function masterFunction)
        {
            var subFunctionList = _langService.MapWithLanguage(_userDetailFunctionList.ContainsKey(masterFunction.FunctionId)
                                    ? _userDetailFunctionList[masterFunction.FunctionId].Where(f => f.IsMenu).ToList()
                                    : null);

            int subMenuCount = subFunctionList == null ? 0 : subFunctionList.Count;

            if (subMenuCount == 0) return;

            var menuBlock = new Menu_MenuBlock_Block();
            menuBlock.BlockId = masterFunction.FunctionId.ToString();
            menuBlock.BlockTitle = masterFunction.Name;

            menuBlock.MenuItem.Clear();
            for (int i = 0; i < subMenuCount; i++) // Sub-menu loop
            {
                var subFunction = subFunctionList[i];
                if (!_isAllowdCustomerCommission && subFunction.FunctionId == _functionCustCommGroup)
                {
                    continue;
                }
                if (_isInternalLogin && subFunction.FunctionId == _fucntionAddNewAccount)
                {
                    continue;
                }

                var menu = new Menu_MenuBlock_MenuItem_Block();

                menu.MenuId = subFunction.FunctionId.ToString();
                menu.MenuTitle = subFunction.Name.ToString();
                menu.NewIcon.Visible = subFunction.IsNew;

                var url = subFunction.Url;
              
                menu.MenuUrl = AppSettings.BaseUrl + url;


                menuBlock.MenuItem.Append(menu);
            }

            _template.MenuBlock.Append(menuBlock);
        }

        #endregion
    }
}
