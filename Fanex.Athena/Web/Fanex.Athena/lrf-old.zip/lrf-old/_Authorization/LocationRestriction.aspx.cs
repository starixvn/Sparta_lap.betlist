﻿using System;
using System.Linq;
using System.Collections.Generic;
using Fanex.Athena.Service.Implement;
using System.Configuration;

public partial class LocationRestriction : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var requestHost = Request.Url.AbsoluteUri;
        var isInternalDomain = requestHost.Contains(ConfigurationManager.AppSettings["internaldomain"]);

        if (isInternalDomain)
        {
            Response.Redirect("SignIn.aspx");
        }
    }
}
