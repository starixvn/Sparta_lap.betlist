﻿using System;
using System.Text;
using System.Web;

namespace Olympus.LRF.UI._Components.DropDownList
{
    /// <summary>
    /// Summary description for SpecialLevelDropdownList
    /// </summary>
    public class SpecialLevelDropdownList
    {
        private const string OptionItemTemplate = "<option {0} value='{1}' class='{2}'> {3} </option>";

        public string SelectedValue
        {
            get
            {
                if (HttpContext.Current != null
                    && !string.IsNullOrEmpty(HttpContext.Current.Request["ddlSpecialLevel"]))
                {
                    return HttpContext.Current.Request["ddlSpecialLevel"];
                }
                return "-1";
            }
        }

        public string RenderContent(int specialLevel, string custId)
        {
            // Assign data source for currency type
            string strSelect = "<select id='ddlSpecialLevel{0}' name='ddlSpecialLevel' onchange='SetSpecialLevel(this, " + custId + ", " + specialLevel + ", \"bgColor" + specialLevel + "\");' class={1}>";
            strSelect = string.Format(strSelect, custId, "bgColor" + specialLevel.ToString());

            var ddlSpecialLevel = new StringBuilder(strSelect);

            for (int i = 0; i <= 10; i++)
            {
                var textValue = i == 0 ? "None" : i.ToString();

                if (specialLevel == i)
                {
                    ddlSpecialLevel.Append(string.Format(OptionItemTemplate,
                                               "selected='selected'",
                        i.ToString(), "bgColor" + i.ToString(),
                                               textValue));
                }
                else
                    ddlSpecialLevel.Append(string.Format(OptionItemTemplate,
                                                (Convert.ToInt32(SelectedValue) == i)
                                               ? "selected='selected'"
                                               : string.Empty,
                        i.ToString(), "bgColor" + i.ToString(),
                                               textValue));
               
            }

            ddlSpecialLevel.Append("</select>");
            return ddlSpecialLevel.ToString();
        }

    }
}
