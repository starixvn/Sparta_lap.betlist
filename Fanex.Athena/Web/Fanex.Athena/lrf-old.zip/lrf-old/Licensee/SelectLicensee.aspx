﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="SelectLicensee.aspx.cs"
         Inherits="Licensee_SelectLicensee" EnableViewState="false" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>LRF &bull; Select a Licensee</title>    
    <link href="resources/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <form id="aspNetForm" runat="server">
    <div id="wrapper">
        <div id="header">
            <div id="userSec" class="r_div">
                <a id="btnLogout" href='javascript:ibc.SignOut()'>
                    <%= Fanex.Athena.Models.ViewModel.ViewResources.Logout %>
                </a>
            </div>
            <div id="welkom" class="r_div">
                <span><%= Fanex.Athena.Models.ViewModel.ViewResources.Welcome %> <%= CurrentUsername() %></span>
            </div>
        </div>
    </div>

    <div class="sel_licensee_title"><%= Fanex.Athena.Models.ViewModel.ViewResources.SelectLicenseeMsg%></div>

    <div class="sel_licensee_main">
        <asp:DataList ID="dlLicensee" runat="server" RepeatColumns="4"
                      RepeatDirection="Horizontal" RepeatLayout="Table">
            <ItemTemplate>
                <p onclick="document.location.href='selectlicensee.aspx?licenseeid=<%#Eval("Id")%>'" style="cursor:pointer">
                    <a>
                        <asp:Literal ID="ltrLicensee" runat="server" Text='<%#Eval("Name")%>'></asp:Literal>
                    </a>
                </p>
            </ItemTemplate>
        </asp:DataList>
    </div>
    
    </form>

    <script src="../_globalresources/js/lib/jquery.min.js" type="text/javascript"></script>

    <script src="../_globalresources/js/lib/jquery.cookie.js" type="text/javascript"></script>

    <script src="../_globalresources/js/core.js" type="text/javascript"></script>

</body>
</html>
