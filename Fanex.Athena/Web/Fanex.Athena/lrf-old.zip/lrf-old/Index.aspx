﻿<%@ Page Language="C#" AutoEventWireup="false" CodeFile="~/Index.aspx.cs" Inherits="Index" %>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>LRF • Reports - Balance</title>
    <%=CSSHelper.ThemeCssLink %>
    <% var appSettings = ConfigurationManager.AppSettings; %>
    <link href="Content/Layout/master.css" rel="stylesheet" type="text/css" />
    <script src="_GlobalResources/Js/lib/jquery.min.js?<%=appSettings["JsVersion"] %>"
        type="text/javascript"></script>
    <script src="_GlobalResources/Js/lib/jquery-ui.min.js?<%=appSettings["JsVersion"] %>"
        type="text/javascript"></script>
    <script src="Scripts/Library/jquery.layout.js?<%=appSettings["JsVersion"] %>" type="text/javascript"></script>
    <script src="Scripts/Global/lrf.layout.js?<%=appSettings["JsVersion"] %>" type="text/javascript"></script>
    <script src="Scripts/Global/site.js?<%=appSettings["JsVersion"] %>" type="text/javascript"></script>
    <script src="_GlobalResources/Js/lib/jquery.blockUI.js?<%=appSettings["JsVersion"] %>"
        type="text/javascript"></script>
    <script language="javascript" type="text/javascript">
        // For use within iPad developer UIWebView
        // Thanks to Andrew Hedges!
        var ua = navigator.userAgent;
        var isiPad = /iPad/i.test(ua) || /iPhone/i.test(ua) || /iPod/i.test(ua);
        if (isiPad) {
            document.location.href = "IndexIpad.aspx";
        }
    </script>
</head>
<body>
    <div class="ui-layout-north">
        <iframe src="<%= Page.ResolveUrl("Header/Index") %>" id="header" name="header"
            width="100%" scrolling="no" frameborder="0" height="52px"></iframe>
    </div>
    <div class="ui-layout-west">
        <iframe src="_Menu/Menu.aspx" scrolling="no" height="100%" id="menu" name="menu"
            width="170px" frameborder="0"></iframe>
    </div>
    <div id="footer" class="ui-layout-south">
        <iframe src="<%= Page.ResolveUrl("~/Footer/Index") %>" height="25px" width="100%"
            scrolling="no" frameborder="0" id="frFooter" name="frFooter"></iframe>
    </div>
    <div id="center" class="ui-layout-center">
        <iframe src="<%= Page.ResolveUrl("~/Report/Balance")%>" id="main" name="main" scrolling="auto"
            width="100%" height="100%" frameborder="0"></iframe>
        <div id="notification_popup">
            <div class="command">
                <input type="button" id="notificaiton_close" />
            </div>
            <div class="popup-title">
                Risk & ForeCast
                <%=Fanex.Athena.Models.ViewModel.ViewResources.Notification %>
            </div>
    <div class="note-message">
        <%=string.Format( Fanex.Athena.Models.ViewModel.ViewResources.LayoutNoteMsg,"<span id=\"browser\"></span>") %>
    </div>
    <div class="browsers">
        <ul>
            <li class="download-chrome"><a target="_blank" href="http://www.google.de/chrome/eula.html?hl=en">
                <%=Fanex.Athena.Models.ViewModel.ViewResources.Download%>
                Google Chrome </a></li>
            <li class="download-firefox"><a target="_blank" href="http://www.mozilla.org/products/download.html?product=firefox-11.0&os=win&lang=en-US">
                <%=Fanex.Athena.Models.ViewModel.ViewResources.Download%>
            </a></li>
            <li class="download-ie"><a target="_blank" href="http://windows.microsoft.com/en-US/internet-explorer/downloads/ie">
                <%=Fanex.Athena.Models.ViewModel.ViewResources.Download%>
            </a></li>
        </ul>
    </div>
    <div class="remove-notif">
        <a href="javascript:;" id="remove_notif_cmd">
            <%=Fanex.Athena.Models.ViewModel.ViewResources.Dontshowagain%>
        </a>
    </div>
    </div> </div>
</body>
</html>
