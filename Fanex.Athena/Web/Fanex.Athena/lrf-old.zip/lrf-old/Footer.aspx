﻿<%@ Page Language="C#" AutoEventWireup="true" EnableSessionState="False" Debug="false" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="Content/Footer/Footer.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="footer">
        <span class="best-view">
            <%=Fanex.Athena.Models.ViewModel.ViewResources.Bestviewedin %>
            <a href="http://windows.microsoft.com/en-US/internet-explorer/downloads/ie" target="_blank">
                IE8+</a>,&nbsp;<a href="http://www.google.de/chrome/?hl=en" target="_blank">Chrome 15+</a>
            or <a href="http://www.mozilla.org/en-US/firefox/fx/" target="_blank">Firefox 10+</a>
        </span><span class="copy-right">Copyright &#169;
            <%=DateTime.Now.Year %>
        </span>
    </div>
</body>
</html>
