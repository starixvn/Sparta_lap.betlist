﻿using System;
using System.Web;
using System.Web.Mvc;
using Microsoft.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using Fanex.Data.Configuration;
using TplCore;
using Fanex.Athena.Extension.Utility;
using Fanex.Athena.Models.DTO.Users;
using Fanex.Athena.Service.Implement.Users;
using System.Web.Http;

using Fanex.Athena.Web.RouterConfig;

/// <summary>
/// Summary description for Global
/// </summary>
public class Global : HttpApplication
{
    public void Application_Start(object sender, EventArgs e)
    {
        TplSettings.UrlVersion = AppSettings.JsVersion;
        AreaRegistration.RegisterAllAreas();
        GlobalConfiguration.Configuration.MessageHandlers.Add(new CompressHandler());

        FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
        RouteConfig.RegisterRoutes(RouteTable.Routes);
        BundleConfig.RegisterBundles(BundleTable.Bundles);
        GlobalConfiguration.Configuration.Formatters.Remove(GlobalConfiguration.Configuration.Formatters.XmlFormatter);
        //DbSettingProviderManager.Current.Start();
    }


    public void Application_End(object sender, EventArgs e)
    {
        //  Code that runs on application shutdown
    }

    public void Application_Error(object sender, EventArgs e)
    {
        // Fanex.SessionPartition.SessionIdManager.HandleUnconnectedSession();

        // Code that runs when an unhandled error occurs
        Exception ex = Server.GetLastError().GetBaseException();
        if (ex is HttpException)
        {
            return;
        }

        string message = ex.Message +
                         "\r\nSOURCE: " + ex.Source +
                         "\r\nDOMAIN: " + HttpContext.Current.Request.Headers["Host"] +
                         "\r\nFORM: " + Request.Form +
                         "\r\nQUERYSTRING: " + Request.QueryString +
                         "\r\nTARGETSITE: " + ex.TargetSite +
                         "\r\nSTACKTRACE: " + ex.StackTrace;
        Fanex.Logging.LogService.Error(message, ex);
    }


    public void Application_AcquireRequestState(object sender, EventArgs e)
    {
        if (!(HttpContext.Current.Handler is IRequiresSessionState)) return;

        // If user session is lost, redirect to login page
        // Validate request & session
        var executeFileName = Request.AppRelativeCurrentExecutionFilePath;
        bool isNewSession = executeFileName == null || executeFileName.IndexOf("_authorization/", StringComparison.CurrentCultureIgnoreCase) >= 0
                            || executeFileName.IndexOf("sso.aspx", StringComparison.CurrentCultureIgnoreCase) >= 0
                            || executeFileName.IndexOf("ssodenyaccess.aspx", StringComparison.CurrentCultureIgnoreCase) >= 0
                            || executeFileName.IndexOf("selectlicensee.aspx", StringComparison.CurrentCultureIgnoreCase) >= 0
                            || executeFileName.IndexOf("whoami.aspx", StringComparison.CurrentCultureIgnoreCase) >= 0;

        if (!isNewSession)
        {
            var sessionService = new SessionService();
            var userSession = sessionService.UserSession;
            var liceseeSession = sessionService.LicenseeSession;
            if (!IsUserAuthenticated(userSession, liceseeSession))
            {
                Response.Redirect(FormsAuthentication.LoginUrl);
            }
            else
            {
                CheckAuthorization(userSession, liceseeSession);
            }
        }
    }

    public void Session_Start(object sender, EventArgs e)
    {
    }

    public void Session_End(object sender, EventArgs e)
    {
    }

    public void Application_BeginRequest(object sender, EventArgs e)
    {

    }

    public void CheckAuthorization(UserSession userSession, LicenseeSession licenseeSession)
    {
        string rawUrl = Request.RawUrl;
        int custId;
        long transId;

        int.TryParse(Request["custid"], out custId);
        long.TryParse(Request["transid"], out transId);

        var authorization = new AuthorizationService();
        bool authorized = authorization.AuthorizePath(licenseeSession.LicenseeId,
                                        userSession.FunctionIdList,
                                        custId,
                                        transId,
                                        rawUrl);

        if (!authorized)
        {
            Server.Transfer(@"~/AccessDenied.aspx");
        }
    }

    private bool IsUserAuthenticated(UserSession userSession, LicenseeSession licenseeSession)
    {
        var context = HttpContext.Current;
        var isAuthenticated = context.User != null
            && context.User.Identity.IsAuthenticated
            && context.Request.IsAuthenticated;

        var isSessionValid = userSession != null
            && userSession.UserId > 0
            && licenseeSession != null
            && licenseeSession.LicenseeId > 0;

        return isAuthenticated && isSessionValid;
    }

    #region Register

    #endregion
}
