﻿<%@ WebHandler Language="C#" Class="LoginCaptcha" %>

using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Web;
using System.Web.SessionState;
using DNAide.Utils;
using Fanex.Athena.Service.Interface.Users;
using Fanex.Athena.Service.Implement.Users;
public class LoginCaptcha : IHttpHandler, IRequiresSessionState
{
    #region IHttpHandler Members

    public void ProcessRequest(HttpContext context)
    {
        ISessionService _sessionService = new SessionService();
        context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        context.Response.Cache.SetNoStore();

        string code = Encryption.RandomNumberString(4).ToUpperInvariant();

        _sessionService.CaptchaCode = code;

        CreateImage(code, context);
    }

    public bool IsReusable
    {
        get { return false; }
    }

    #endregion

    private static void CreateImage(string code, HttpContext hc)
    {
        int iwidth = code.Length * 12 + 10;
        var image = new Bitmap(iwidth, 20);
        Graphics g = Graphics.FromImage(image);
        var random = new Random();

        var fonts = new[] { "Tahoma", "Arial" };

        var f = new Font(fonts[random.Next(0, fonts.Length - 1)], 11, FontStyle.Bold);
        Brush b = new SolidBrush(Color.White);
        g.Clear(Color.DimGray);

        g.DrawString(code, f, b, random.Next(2, 12), random.Next(-1, 1));
        g.DrawRectangle(new Pen(Color.Black), 0, 0, image.Width - 1, image.Height - 1);


        for (int i = 0; i < 50; i++)
        {
            int x = random.Next(image.Width);
            int y = random.Next(image.Height);
            image.SetPixel(x, y, Color.FromArgb(random.Next()));
        }

        var ms = new MemoryStream();
        image.Save(ms, ImageFormat.Png);
        hc.Response.ClearContent();
        hc.Response.ContentType = "image/png";

        hc.Response.BinaryWrite(ms.ToArray());
        g.Dispose();
        image.Dispose();
    }
}