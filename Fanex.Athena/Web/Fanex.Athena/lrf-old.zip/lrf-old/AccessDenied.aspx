<%@ Page Language="C#" AutoEventWireup="false" %>
<script runat="server">
    private Fanex.Athena.Service.Interface.Common.ILanguageService langService = new Fanex.Athena.Service.Implement.Common.LanguageService();
    protected override void InitializeCulture()
    {
        var currentLanguage = langService.GetCurrentLanguage();
        langService.SetPageCulture(currentLanguage);
    }
</script>
<%
    
    if (!Request.FilePath.Contains("/Report/Balance/"))
    {
        Response.Write(new Olympus.LRF.UI._Components.ErrorPage_Page(Fanex.Athena.Models.ViewModel.ViewResources.AccessDeniedMsg));
    }
    else
    {
        Response.Write("&nbsp;");
    }
%>