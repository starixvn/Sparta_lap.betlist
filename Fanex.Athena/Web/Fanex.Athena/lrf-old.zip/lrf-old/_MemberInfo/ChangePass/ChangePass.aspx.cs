﻿using System.Collections;
using System.Linq;
using System.Web.UI;
using Olympus.LRF.UI._Base;


namespace Olympus.LRF.UI._MemberInfo.ChangePass
{
    public partial class _MemberInfo_ChangePass : TplPage
    {
        public override void RenderContent(HtmlTextWriter writer)
        {
            RegisterJavascriptObject("alertInputOldPwd", Fanex.Athena.Models.ViewModel.ViewResources.AlertInputOldPwdMsg);
            RegisterJavascriptObject("alertPasswordEmpty", Fanex.Athena.Models.ViewModel.ViewResources.AlertPasswordEmptyMsg);
            RegisterJavascriptObject("alertErrorConfirm", Fanex.Athena.Models.ViewModel.ViewResources.PasswordConfirmErrorMsg);
            RegisterJavascriptObject("alertPasswordRequire", Fanex.Athena.Models.ViewModel.ViewResources.PasswordNoteMsg);
            RegisterJavascriptObject("alertPasswordSucc", Fanex.Athena.Models.ViewModel.ViewResources.PasswordChangedMsg);

            var tpl = new ChangePass_Template();

            writer.Write(tpl);
        }


        public override void ProcessRequest(ref Hashtable p)
        {
        }

        public override object ValidateRequest(Hashtable p)
        {
            return null;
        }

        public override object InvokeData(Hashtable p)
        {
            return null;
        }
    }
}