﻿using System;
using System.Web;

/// <summary>
/// Summary description for RequestHelper
/// </summary>
public static class RequestHelper
{
    /// <summary>
    /// Get int request value
    /// </summary>
    /// <param name="name"></param>
    /// <param name="defaultValue"></param>
    /// <returns></returns>
    public static int GetIntRequest(string name, int defaultValue)
    {
        if (string.IsNullOrEmpty(HttpContext.Current.Request[name])) return defaultValue;
        int value;
        return !int.TryParse(HttpContext.Current.Request[name], out value)
            ? defaultValue 
            : value;
    }

    /// <summary>
    /// Get DateTime request
    /// </summary>
    /// <param name="name"></param>
    /// <param name="defaultValue"></param>
    /// <returns></returns>
    public static DateTime GetDateTimeRequest(string name, DateTime defaultValue)
    {
        if (string.IsNullOrEmpty(HttpContext.Current.Request[name])) return defaultValue;
        DateTime value = DateTime.Now;
        return !DateTime.TryParse(HttpContext.Current.Request[name], out value) 
            ? defaultValue 
            : value;
    }

    /// <summary>
    /// Get boolean request
    /// </summary>
    /// <param name="name"></param>
    /// <param name="defaultValue"></param>
    /// <returns></returns>
    /// 
    public static bool GetBooleanRequest(string name, bool defaultValue)
    {
        if (string.IsNullOrEmpty(HttpContext.Current.Request[name])) return defaultValue;

        string value = HttpContext.Current.Request[name].ToLower();

        return value == "1" || value == "on" || value == "true" || value == "True";
    }

    /// <summary>
    /// Get string request
    /// 
    /// </summary>
    /// <param name="name"></param>
    /// <param name="defaultValue"></param>
    /// <returns></returns>
    public static string GetStringRequest(string name, string defaultValue)
    {
        return string.IsNullOrEmpty(HttpContext.Current.Request[name]) 
            ? defaultValue 
            : HttpContext.Current.Request[name];
    }

    /// <summary>
    /// Get long request
    /// </summary>
    /// <param name="name"></param>
    /// <param name="defaultValue"></param>
    /// <returns></returns>
    public static long GetLongRequest(string name, long defaultValue)
    {
        if (string.IsNullOrEmpty(HttpContext.Current.Request[name])) return defaultValue;
        long value;
        return !long.TryParse(HttpContext.Current.Request[name], out value) ? defaultValue : value;
    }

    /// <summary>
    /// Get decimal request
    /// </summary>
    /// <param name="name"></param>
    /// <param name="defaultValue"></param>
    /// <returns></returns>
    public static decimal GetDecimalRequest(string name, decimal defaultValue)
    {
        if (string.IsNullOrEmpty(HttpContext.Current.Request[name])) return defaultValue;
        decimal value;
        return !decimal.TryParse(HttpContext.Current.Request[name], out value) 
            ? defaultValue 
            : value;
    }

    /// <summary>
    /// Get double request
    /// </summary>
    /// <param name="name"></param>
    /// <param name="defaultValue"></param>
    /// <returns></returns>
    public static double GetDoubleRequest(string name, double defaultValue)
    {
        if (string.IsNullOrEmpty(HttpContext.Current.Request[name])) return defaultValue;
        double value = 0;
        return !double.TryParse(HttpContext.Current.Request[name], out value) 
            ? defaultValue 
            : value;
    }
}